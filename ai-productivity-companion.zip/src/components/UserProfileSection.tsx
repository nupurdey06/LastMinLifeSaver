import React, { useState, useEffect } from 'react';
import { UserProfile, Task, Goal } from '../types';
import { Theme, THEMES } from '../theme';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Bot, 
  Sparkles, 
  Settings, 
  Trash2, 
  Volume2, 
  VolumeX, 
  Bell, 
  Palette, 
  Check, 
  CheckCircle2, 
  Award, 
  Clock, 
  Activity, 
  Flame, 
  Zap, 
  Brain, 
  Calendar, 
  CalendarCheck, 
  RefreshCw, 
  Sliders, 
  Edit3, 
  Save, 
  FileJson, 
  Plus, 
  Info,
  ShieldAlert,
  Loader2,
  Mail,
  Briefcase
} from 'lucide-react';

interface UserProfileSectionProps {
  userProfile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
  tasks: Task[];
  goals: Goal[];
  themeKey: string;
  onChangeTheme: (themeKey: string) => void;
  activeTheme?: Theme;
}

const DEFAULT_AVATARS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80"
];

const PRESET_BADGES = [
  { id: 'streak-1', name: 'Flame Starter', desc: 'Maintain a 3-day completion streak', icon: Flame, color: 'text-orange-500 bg-orange-50 border-orange-100', condition: (streak: number, completed: number) => streak >= 3 },
  { id: 'streak-2', name: 'Streak Legend', desc: 'Achieve a 10-day focus streak', icon: Flame, color: 'text-red-500 bg-red-50 border-red-100', condition: (streak: number, completed: number) => streak >= 10 },
  { id: 'tasks-1', name: 'Focus Rookie', desc: 'Complete 3 productive tasks', icon: CheckCircle2, color: 'text-teal-500 bg-teal-50 border-teal-100', condition: (streak: number, completed: number) => completed >= 3 },
  { id: 'tasks-2', name: 'Productivity Titan', desc: 'Complete 10 tasks successfully', icon: Award, color: 'text-indigo-500 bg-indigo-50 border-indigo-100', condition: (streak: number, completed: number) => completed >= 10 },
  { id: 'habits-1', name: 'Deep Work Master', desc: 'Optimize schedule with Peak Focus blocks', icon: Brain, color: 'text-purple-500 bg-purple-50 border-purple-100', condition: (streak: number, completed: number) => completed >= 5 },
  { id: 'goals-1', name: 'Goal Crusher', desc: 'Set and execute long-term milestones', icon: Target, color: 'text-amber-500 bg-amber-50 border-amber-100', condition: (streak: number, completed: number) => true }
];

// Helper mock icon for Badge
function Target({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
}

export default function UserProfileSection({
  userProfile,
  onUpdateProfile,
  tasks,
  goals,
  themeKey,
  onChangeTheme,
  activeTheme = THEMES.slate
}: UserProfileSectionProps) {
  // Local state for profile and preferences
  const [activeProfileTab, setActiveProfileTab] = useState<'profile' | 'habits' | 'goals' | 'preferences' | 'privacy' | 'theme'>('profile');
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileName, setProfileName] = useState(userProfile.name);
  const [profileRole, setProfileRole] = useState(userProfile.customRole);
  const [profileEmail, setProfileEmail] = useState(() => localStorage.getItem('winwise_user_email') || 'aryan.focus@winwise.io');
  const [avatarUrl, setAvatarUrl] = useState(() => userProfile.avatarUrl || localStorage.getItem('winwise_avatar_url') || DEFAULT_AVATARS[0]);
  const [customUrlInput, setCustomUrlInput] = useState(() => userProfile.avatarUrl || localStorage.getItem('winwise_avatar_url') || DEFAULT_AVATARS[0]);
  const [showAvatarSelector, setShowAvatarSelector] = useState(false);

  useEffect(() => {
    if (userProfile.avatarUrl) {
      setAvatarUrl(userProfile.avatarUrl);
      setCustomUrlInput(userProfile.avatarUrl);
    }
  }, [userProfile.avatarUrl]);

  // Settings & Preferences
  const [isCalendarSynced, setIsCalendarSynced] = useState(() => localStorage.getItem('winwise_calendar_sync') === 'true');
  const [syncTime, setSyncTime] = useState(() => localStorage.getItem('winwise_sync_time') || 'Never');
  const [isSyncing, setIsSyncing] = useState(false);

  const [notificationIntensity, setNotificationIntensity] = useState(() => localStorage.getItem('winwise_notification_intensity') || 'Medium');
  const [voiceSpeed, setVoiceSpeed] = useState(() => localStorage.getItem('winwise_voice_speed') || 'Normal');
  const [voiceSpokenAloud, setVoiceSpokenAloud] = useState(() => localStorage.getItem('winwise_voice_aloud') !== 'false');

  // Accessibility & Interface Settings
  const [reduceMotion, setReduceMotion] = useState(() => localStorage.getItem('winwise_reduce_motion') === 'true');
  const [highReadabilityFont, setHighReadabilityFont] = useState(() => localStorage.getItem('winwise_readability_font') === 'true');
  const [themeMode, setThemeMode] = useState(() => localStorage.getItem('winwise_theme_mode') || 'Light');

  // AI Learnings, Peak Focus, Habits, Personality
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [productivityScore, setProductivityScore] = useState(84);
  const [personality, setPersonality] = useState('Consistent Achiever');
  const [personalityDesc, setPersonalityDesc] = useState('Strategic performer who consistently allocates peak focus times to achieve long-term study milestones.');
  const [peakPeriods, setPeakPeriods] = useState([
    { start: '09:00', end: '11:30', label: 'Morning Peak' },
    { start: '16:00', end: '17:30', label: 'Afternoon Flow' }
  ]);
  const [workHabits, setWorkHabits] = useState({
    preferredSessionLength: 45,
    idealBreakFrequency: 10,
    averageTaskCompletionTime: 50
  });
  const [strengths, setStrengths] = useState([
    'Maintains high consistency on Study category tasks.',
    'Sets structured, actionable sub-tasks before execution.',
    'Leverages scheduled breaks to avoid decision fatigue.'
  ]);
  const [improvements, setImprovements] = useState([
    'Vulnerable to late-day procrastination on complex coding blocks.',
    'Requires tighter break discipline during afternoon dips.',
    'Tends to overestimate capacity for Low priority tasks.'
  ]);
  const [insightsTab, setInsightsTab] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [customRecommendations, setCustomRecommendations] = useState([
    'Set a strict 45-minute sprint with Sera helper to start your review timeline.',
    'Move administrative work or general chats to late-afternoon focus drop zones.',
    'Align studying milestones directly with your Board Exams goal.'
  ]);

  // AI Memory Facts Management
  const [memoryFacts, setMemoryFacts] = useState<string[]>(() => {
    const saved = localStorage.getItem('winwise_ai_memories');
    if (saved) return JSON.parse(saved);
    return [
      'Prefers executing major study cards in early morning hours.',
      'Slightly prone to rescheduling deadlines on Fridays.',
      'Uses Pomodoro-style sessions of 45-minutes for study.',
      'Strives to balance student commitments with entrepreneurial goals.',
      'Highly motivated by milestone streaks and visual badges.'
    ];
  });
  const [newMemoryInput, setNewMemoryInput] = useState('');

  // Save changes
  useEffect(() => {
    localStorage.setItem('winwise_ai_memories', JSON.stringify(memoryFacts));
  }, [memoryFacts]);

  // Load initially computed statistics
  useEffect(() => {
    const savedScore = localStorage.getItem('winwise_profile_score');
    if (savedScore) setProductivityScore(parseInt(savedScore));
    
    const savedPersonality = localStorage.getItem('winwise_profile_personality');
    if (savedPersonality) setPersonality(savedPersonality);

    const savedDesc = localStorage.getItem('winwise_profile_personality_desc');
    if (savedDesc) setPersonalityDesc(savedDesc);

    const savedHabits = localStorage.getItem('winwise_profile_habits');
    if (savedHabits) setWorkHabits(JSON.parse(savedHabits));

    const savedStrengths = localStorage.getItem('winwise_profile_strengths');
    if (savedStrengths) setStrengths(JSON.parse(savedStrengths));

    const savedImprovements = localStorage.getItem('winwise_profile_improvements');
    if (savedImprovements) setImprovements(JSON.parse(savedImprovements));

    const savedRecs = localStorage.getItem('winwise_profile_recs');
    if (savedRecs) setCustomRecommendations(JSON.parse(savedRecs));

    const savedPeaks = localStorage.getItem('winwise_profile_peaks');
    if (savedPeaks) setPeakPeriods(JSON.parse(savedPeaks));
  }, []);

  const totalCompletedTasks = tasks.filter(t => t.completed).length;

  // Real-time recalculation of productivity score based on stats
  const calculatedCompletionRate = tasks.length > 0 
    ? Math.round((totalCompletedTasks / tasks.length) * 100) 
    : 75;

  const currentScore = Math.min(100, Math.max(40, calculatedCompletionRate + (userProfile.streakDays * 2)));

  // Perform AI analysis via Gemini
  const handleTriggerAIAnalysis = async () => {
    setAiAnalyzing(true);
    try {
      const response = await fetch('/api/profile/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userProfile,
          tasks,
          goals,
          preferredHours: { start: '09:00', end: '17:00' },
          existingMemories: memoryFacts
        })
      });

      if (!response.ok) throw new Error("API analysis request failed");
      const data = await response.json();

      setProductivityScore(data.productivityScore);
      setPersonality(data.productivityPersonality);
      setPersonalityDesc(data.personalityDescription);
      setPeakPeriods(data.peakFocusPeriods);
      setWorkHabits(data.learnedHabits);
      setStrengths(data.strengths);
      setImprovements(data.improvements);
      setCustomRecommendations(data.recommendations);
      setMemoryFacts(data.learnedMemories);

      // Save to localStorage
      localStorage.setItem('winwise_profile_score', data.productivityScore.toString());
      localStorage.setItem('winwise_profile_personality', data.productivityPersonality);
      localStorage.setItem('winwise_profile_personality_desc', data.personalityDescription);
      localStorage.setItem('winwise_profile_habits', JSON.stringify(data.learnedHabits));
      localStorage.setItem('winwise_profile_strengths', JSON.stringify(data.strengths));
      localStorage.setItem('winwise_profile_improvements', JSON.stringify(data.improvements));
      localStorage.setItem('winwise_profile_recs', JSON.stringify(data.recommendations));
      localStorage.setItem('winwise_profile_peaks', JSON.stringify(data.peakFocusPeriods));

    } catch (e) {
      console.error("AI Analysis error. Falling back to analytical defaults...", e);
    } finally {
      setAiAnalyzing(false);
    }
  };

  const handleSaveProfile = () => {
    onUpdateProfile({
      ...userProfile,
      name: profileName,
      customRole: profileRole,
      avatarUrl: avatarUrl
    });
    localStorage.setItem('winwise_user_email', profileEmail);
    localStorage.setItem('winwise_avatar_url', avatarUrl);
    setIsEditingProfile(false);
  };

  const handleCalendarSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsCalendarSynced(true);
      const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setSyncTime(timeStr);
      localStorage.setItem('winwise_calendar_sync', 'true');
      localStorage.setItem('winwise_sync_time', timeStr);
      setIsSyncing(false);
    }, 1200);
  };

  const handleAddMemory = () => {
    if (!newMemoryInput.trim()) return;
    setMemoryFacts(prev => [...prev, newMemoryInput.trim()]);
    setNewMemoryInput('');
  };

  const handleDeleteMemory = (index: number) => {
    setMemoryFacts(prev => prev.filter((_, i) => i !== index));
  };

  const handleExportMemories = () => {
    const memoryData = {
      user: {
        name: userProfile.name,
        role: userProfile.customRole,
        email: profileEmail
      },
      exportedAt: new Date().toISOString(),
      score: productivityScore,
      personality: personality,
      habits: workHabits,
      memories: memoryFacts
    };
    const blob = new Blob([JSON.stringify(memoryData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${userProfile.name.toLowerCase()}_winwise_memory.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClearMemory = () => {
    if (confirm("Are you sure you want to delete all long-term memories? This will clean Sera's learned patterns and reset customization options.")) {
      setMemoryFacts([]);
      localStorage.removeItem('winwise_ai_memories');
    }
  };

  // Synchronize settings changes
  const toggleVoiceAloud = () => {
    const val = !voiceSpokenAloud;
    setVoiceSpokenAloud(val);
    localStorage.setItem('winwise_voice_aloud', val.toString());
  };

  const changeAccessibilityMotion = () => {
    const val = !reduceMotion;
    setReduceMotion(val);
    localStorage.setItem('winwise_reduce_motion', val.toString());
  };

  const changeAccessibilityFont = () => {
    const val = !highReadabilityFont;
    setHighReadabilityFont(val);
    localStorage.setItem('winwise_readability_font', val.toString());
  };

  const menuItems = [
    { id: 'profile', label: 'Identity & Badges', icon: User, desc: 'User persona, details, and milestones' },
    { id: 'habits', label: 'AI Habits & Analytics', icon: Brain, desc: 'Productivity score, personality, and habits' },
    { id: 'goals', label: 'Long-Term Goals', icon: CalendarCheck, desc: 'Progress meters for active milestones' },
    { id: 'preferences', label: 'Voice & Sync', icon: Settings, desc: 'Sera voice rates and calendar status' },
    { id: 'privacy', label: 'AI Memory & GDPR', icon: ShieldAlert, desc: 'Edit learned facts and export data' },
    { id: 'theme', label: 'Workspace Style', icon: Palette, desc: 'Theme colors and accessibility tools' }
  ] as const;

  return (
    <div className={`space-y-6 ${highReadabilityFont ? 'font-mono text-[13px]' : 'text-xs'}`}>
      
      {/* 1. COMPACT HERO HEADER BANNER */}
      <div className="bg-gradient-to-r from-gray-950 via-gray-900 to-indigo-950 rounded-2xl p-6 text-white relative overflow-hidden shadow-sm">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(99,102,241,0.15),transparent_60%)] pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <span className="text-[10px] font-bold tracking-widest text-indigo-300 uppercase block mb-1">WinWise Core Settings</span>
            <h2 className="text-xl font-display font-bold tracking-tight">Sera Intelligence & Profile</h2>
            <p className="text-gray-400 text-xs mt-1 max-w-xl">Configure your learning companion, customize the workspace layout, and manage long-term habit patterns.</p>
          </div>
          <button
            onClick={handleTriggerAIAnalysis}
            disabled={aiAnalyzing}
            className="shrink-0 bg-white hover:bg-gray-100 text-gray-900 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition-all shadow-md disabled:opacity-50"
          >
            {aiAnalyzing ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                Processing Statistics...
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                Analyze Stats with AI
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. DUAL COLUMNS SETTINGS CONTAINER */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: NAVIGATION LIST */}
        <div className="lg:col-span-4 bg-white border border-gray-100 rounded-2xl p-4 shadow-3xs space-y-2">
          <div className="hidden lg:block text-[10px] text-gray-400 font-bold uppercase tracking-wider px-3 pb-2 border-b border-gray-50">
            Settings Category
          </div>

          {/* Desktop Vertical Menu & Mobile Scrollbar Tab Selector */}
          <div className="flex lg:flex-col gap-1.5 overflow-x-auto pb-2 lg:pb-0 scrollbar-none snap-x">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeProfileTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveProfileTab(item.id);
                    setIsEditingProfile(false);
                  }}
                  className={`w-full text-left p-3 rounded-xl flex items-center gap-3.5 transition-all shrink-0 lg:shrink snap-start ${
                    isActive 
                      ? `${activeTheme.primaryBg} text-white shadow-xs` 
                      : 'bg-transparent text-gray-500 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                  style={{ minWidth: '170px' }}
                >
                  <div className={`p-2 rounded-lg shrink-0 ${isActive ? 'bg-white/15 text-white' : 'bg-gray-100/70 text-gray-400'}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold truncate">{item.label}</div>
                    <div className={`text-[9px] truncate hidden lg:block ${isActive ? 'text-white/70' : 'text-gray-400 font-semibold'}`}>
                      {item.desc}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIVE TAB PANEL WITH ANIMATION */}
        <div className="lg:col-span-8 space-y-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeProfileTab}
              initial={reduceMotion ? {} : { opacity: 0, y: 10 }}
              animate={reduceMotion ? {} : { opacity: 1, y: 0 }}
              exit={reduceMotion ? {} : { opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="space-y-6"
            >
              
              {/* TAB 1: IDENTITY & BADGES */}
              {activeProfileTab === 'profile' && (
                <div className="space-y-6">
                  
                  {/* Hero Card */}
                  <div id="profile-hero-card" className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-radial from-gray-50/60 to-transparent pointer-events-none rounded-full" />
                    
                    <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center relative z-10">
                      
                      {/* Profile Photo selector */}
                      <div className="relative group shrink-0">
                        <img 
                          src={avatarUrl} 
                          alt={userProfile.name} 
                          referrerPolicy="no-referrer"
                          className="w-20 h-20 rounded-full object-cover ring-2 ring-gray-100 shadow-md bg-gray-50" 
                        />
                        <button
                          onClick={() => setShowAvatarSelector(!showAvatarSelector)}
                          className="absolute -bottom-1.5 -right-1.5 bg-white border border-gray-150 p-1.5 rounded-full shadow-md text-gray-500 hover:text-gray-900 transition-colors"
                          title="Change Profile Photo"
                        >
                          <Edit3 className="w-3 h-3" />
                        </button>
                        
                        {showAvatarSelector && (
                          <div className="absolute top-22 left-0 bg-white border border-gray-150 p-2.5 rounded-xl shadow-lg z-30 flex gap-2 w-56 flex-wrap">
                            <div className="text-[10px] text-gray-400 font-bold uppercase w-full mb-1">Select Avatar</div>
                            {DEFAULT_AVATARS.map((url, i) => {
                              const isSelected = avatarUrl === url;
                              return (
                                <button 
                                  key={i} 
                                  onClick={() => {
                                    setAvatarUrl(url);
                                    setCustomUrlInput(url);
                                    setShowAvatarSelector(false);
                                    localStorage.setItem('winwise_avatar_url', url);
                                    onUpdateProfile({
                                      ...userProfile,
                                      avatarUrl: url
                                    });
                                  }}
                                  className={`w-10 h-10 rounded-full overflow-hidden border-2 transition-all shrink-0 ${
                                    isSelected ? 'border-indigo-500 scale-105 shadow-sm' : 'border-transparent hover:border-gray-300'
                                  }`}
                                >
                                  <img src={url} alt="" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                                </button>
                              );
                            })}
                            <div className="w-full border-t border-gray-100 pt-2 mt-1.5 flex flex-col gap-1.5">
                              <span className="text-[9px] text-gray-400 font-bold uppercase block">Or Custom URL</span>
                              <div className="flex gap-1">
                                <input
                                  type="text"
                                  placeholder="https://..."
                                  value={customUrlInput}
                                  onChange={(e) => setCustomUrlInput(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      const trimmed = customUrlInput.trim();
                                      if (trimmed) {
                                        setAvatarUrl(trimmed);
                                        localStorage.setItem('winwise_avatar_url', trimmed);
                                        onUpdateProfile({
                                          ...userProfile,
                                          avatarUrl: trimmed
                                        });
                                        setShowAvatarSelector(false);
                                      }
                                    }
                                  }}
                                  className="flex-1 text-[10px] p-1.5 border border-gray-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white dark:bg-slate-800"
                                />
                                <button
                                  type="button"
                                  onClick={() => {
                                    const trimmed = customUrlInput.trim();
                                    if (trimmed) {
                                      setAvatarUrl(trimmed);
                                      localStorage.setItem('winwise_avatar_url', trimmed);
                                      onUpdateProfile({
                                        ...userProfile,
                                        avatarUrl: trimmed
                                      });
                                      setShowAvatarSelector(false);
                                    }
                                  }}
                                  className="text-[10px] bg-indigo-600 hover:bg-indigo-700 text-white px-2 py-1.5 rounded-md font-bold transition-all shrink-0 cursor-pointer"
                                >
                                  Apply
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Details Edit */}
                      <div className="flex-1 w-full space-y-2">
                        {isEditingProfile ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Full Name</label>
                              <input
                                type="text"
                                value={profileName}
                                onChange={(e) => setProfileName(e.target.value)}
                                className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Occupation / Persona</label>
                              <input
                                type="text"
                                value={profileRole}
                                onChange={(e) => setProfileRole(e.target.value)}
                                className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                                placeholder="Student, Professional, etc."
                              />
                            </div>
                            <div className="space-y-1 sm:col-span-2">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Email Address</label>
                              <input
                                type="email"
                                value={profileEmail}
                                onChange={(e) => setProfileEmail(e.target.value)}
                                className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                              />
                            </div>
                            <div className="flex gap-2 pt-2 sm:col-span-2">
                              <button
                                onClick={handleSaveProfile}
                                className="px-3 py-1.5 rounded-lg text-white font-semibold text-xs flex items-center gap-1 bg-green-600 hover:bg-green-700 transition-colors shadow-xs"
                              >
                                <Save className="w-3.5 h-3.5" /> Save Changes
                              </button>
                              <button
                                onClick={() => {
                                  setProfileName(userProfile.name);
                                  setProfileRole(userProfile.customRole);
                                  setIsEditingProfile(false);
                                }}
                                className="px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 font-semibold text-xs transition-colors"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div>
                            <div className="flex items-center gap-3">
                              <h1 className="text-xl font-display font-bold text-gray-900 tracking-tight">{userProfile.name}</h1>
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${activeTheme.accentBadge}`}>
                                {userProfile.customRole || "User"}
                              </span>
                            </div>
                            
                            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-gray-500 mt-2 font-medium">
                              <span className="flex items-center gap-1">
                                <Mail className="w-3.5 h-3.5 text-gray-400" />
                                {profileEmail}
                              </span>
                              <span className="flex items-center gap-1">
                                <Briefcase className="w-3.5 h-3.5 text-gray-400" />
                                {userProfile.customRole} Role Workspace
                              </span>
                            </div>

                            <div className="flex items-center gap-2 mt-4">
                              <button
                                onClick={() => setIsEditingProfile(true)}
                                className="px-3 py-1.5 rounded-lg border border-gray-150 text-gray-600 hover:text-gray-900 hover:bg-gray-50 text-xs font-semibold flex items-center gap-1 transition-all"
                              >
                                <Edit3 className="w-3.5 h-3.5" /> Edit Profile Details
                              </button>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Streak Counters */}
                      <div className="flex gap-3 shrink-0 self-stretch sm:self-auto justify-between sm:justify-start">
                        <div className="bg-orange-50/70 border border-orange-100 rounded-xl p-3 text-center min-w-[76px] flex flex-col justify-center">
                          <Flame className="w-5 h-5 text-orange-500 mx-auto animate-bounce mb-1" />
                          <div className="text-xs font-bold text-orange-950">{userProfile.streakDays} Days</div>
                          <div className="text-[9px] text-orange-700 uppercase font-bold tracking-wider mt-0.5">Focus Streak</div>
                        </div>
                        <div className="bg-teal-50/70 border border-teal-100 rounded-xl p-3 text-center min-w-[76px] flex flex-col justify-center">
                          <CheckCircle2 className="w-5 h-5 text-teal-600 mx-auto mb-1" />
                          <div className="text-xs font-bold text-teal-950">{totalCompletedTasks} Cards</div>
                          <div className="text-[9px] text-teal-700 uppercase font-bold tracking-wider mt-0.5">Completed</div>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Achievements and Badges Panel */}
                  <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4">
                    <div>
                      <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                        <Award className="w-4 h-4 text-yellow-500" />
                        Unlocked Badges & Achievements
                      </h3>
                      <p className="text-gray-500 text-[10px] mt-0.5">Badges activate automatically based on your daily study consistency</p>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {PRESET_BADGES.map((badge) => {
                        const unlocked = badge.condition(userProfile.streakDays, totalCompletedTasks);
                        const BadgeIcon = badge.icon;

                        return (
                          <div 
                            key={badge.id}
                            className={`p-3.5 rounded-xl border text-center transition-all ${
                              unlocked 
                                ? `${badge.color} shadow-xs` 
                                : 'bg-gray-50/50 border-gray-150 text-gray-300 opacity-60'
                            }`}
                          >
                            <BadgeIcon className={`w-7 h-7 mx-auto mb-2 ${unlocked ? '' : 'text-gray-300'}`} />
                            <div className="text-[10px] font-bold leading-tight line-clamp-1">{badge.name}</div>
                            <div className="text-[9px] text-gray-500 mt-1">{badge.desc}</div>
                            <div className="text-[8px] font-bold mt-2 uppercase tracking-wide">
                              {unlocked ? '🏆 Unlocked' : '🔒 Locked'}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>
              )}

              {/* TAB 2: AI HABITS & ANALYTICS */}
              {activeProfileTab === 'habits' && (
                <div className="space-y-6">
                  
                  {/* Score & Personality Block */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                    <div className="md:col-span-5 bg-white rounded-2xl border border-gray-100 p-5 shadow-xs flex flex-col justify-between">
                      <div>
                        <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                          <Activity className="w-4 h-4 text-indigo-500" />
                          AI Productivity Score
                        </h3>
                        <p className="text-gray-500 text-[10px] mt-0.5">Updated based on daily consistency</p>
                      </div>

                      <div className="relative flex items-center justify-center my-6">
                        <svg className="w-28 h-28 transform -rotate-90">
                          <circle
                            cx="56"
                            cy="56"
                            r="46"
                            className="stroke-gray-100"
                            strokeWidth="8"
                            fill="transparent"
                          />
                          <circle
                            cx="56"
                            cy="56"
                            r="46"
                            className="stroke-indigo-600 transition-all duration-1000 ease-out"
                            strokeWidth="8"
                            fill="transparent"
                            strokeDasharray={2 * Math.PI * 46}
                            strokeDashoffset={2 * Math.PI * 46 * (1 - productivityScore / 100)}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div className="absolute text-center">
                          <span className="text-2xl font-display font-extrabold text-gray-900">{productivityScore}</span>
                          <span className="text-[9px] text-gray-400 block font-bold uppercase tracking-wide">out of 100</span>
                        </div>
                      </div>

                      <div className="bg-gray-50 rounded-xl p-2.5 border border-gray-100 text-center">
                        <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider block">Score Level</span>
                        <span className="text-xs font-bold text-gray-800 mt-0.5 block">
                          {productivityScore >= 90 ? '🔥 Elite Producer' : productivityScore >= 75 ? '⚡ High Achiever' : '📈 Developing Consistency'}
                        </span>
                      </div>
                    </div>

                    <div className="md:col-span-7 bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4 flex flex-col justify-between">
                      <div>
                        <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                          <Brain className="w-4 h-4 text-purple-500" />
                          AI Productivity Personality
                        </h3>
                        <p className="text-gray-500 text-[10px] mt-0.5">Archetype generated by the learning engine</p>
                      </div>

                      <div className="bg-gradient-to-r from-purple-50/50 to-indigo-50/20 p-4 rounded-xl border border-purple-100/50">
                        <h4 className="font-display font-bold text-sm text-purple-950 flex items-center gap-1">
                          <Sparkles className="w-4 h-4 text-purple-500" />
                          {personality}
                        </h4>
                        <p className="text-[11px] text-purple-900 leading-relaxed mt-1 font-medium">{personalityDesc}</p>
                      </div>

                      <div className="grid grid-cols-3 gap-2.5 pt-1">
                        <div className="bg-gray-50 rounded-xl p-2 border border-gray-100 text-center">
                          <span className="text-[8px] text-gray-400 font-bold block uppercase">Session Length</span>
                          <span className="text-xs font-bold text-gray-800 block mt-0.5">{workHabits.preferredSessionLength}m</span>
                        </div>
                        <div className="bg-gray-50 rounded-xl p-2 border border-gray-100 text-center">
                          <span className="text-[8px] text-gray-400 font-bold block uppercase">Ideal Break</span>
                          <span className="text-xs font-bold text-gray-800 block mt-0.5">{workHabits.idealBreakFrequency}m</span>
                        </div>
                        <div className="bg-gray-50 rounded-xl p-2 border border-gray-100 text-center">
                          <span className="text-[8px] text-gray-400 font-bold block uppercase">Avg Card Time</span>
                          <span className="text-xs font-bold text-gray-800 block mt-0.5">~{workHabits.averageTaskCompletionTime}m</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Detected Focus Periods and Audits */}
                  <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4">
                    <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                      <Sliders className="w-4 h-4 text-emerald-500" />
                      AI Habit Audit (Strengths & Improvements)
                    </h3>

                    <div className="space-y-1.5 border-b border-gray-100 pb-3">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wide block">Preferred Working Hours & Peak States</span>
                      <div className="flex gap-2 flex-wrap">
                        {peakPeriods.map((period, i) => (
                          <div key={i} className="flex items-center gap-1.5 bg-indigo-50/40 border border-indigo-100/50 py-1 px-2.5 rounded-lg text-[10px] text-indigo-950 font-bold">
                            <Clock className="w-3.5 h-3.5 text-indigo-500" />
                            <span>{period.label}: {period.start} - {period.end}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                      <div>
                        <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wide block mb-1">Detected Strengths</span>
                        <ul className="space-y-1.5">
                          {strengths.map((str, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-gray-700 font-medium">
                              <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                              <span>{str}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wide block mb-1">Improvement Areas</span>
                        <ul className="space-y-1.5">
                          {improvements.map((imp, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-gray-700 font-medium">
                              <Info className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                              <span>{imp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  {/* Recommendations with Daily / Weekly / Monthly tabs */}
                  <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4">
                    <div className="flex justify-between items-center border-b border-gray-100 pb-2.5">
                      <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-yellow-500" />
                        Adaptive Coaching & Recommendations
                      </h3>
                      
                      <div className="flex gap-1 bg-gray-50 p-1 rounded-lg border border-gray-100">
                        {(['daily', 'weekly', 'monthly'] as const).map((tab) => (
                          <button
                            key={tab}
                            onClick={() => {
                              setInsightsTab(tab);
                              if (tab === 'daily') {
                                setCustomRecommendations([
                                  'Set a strict 45-minute sprint with Sera helper to start your review timeline.',
                                  'Move administrative work or general chats to late-afternoon focus drop zones.',
                                  'Align studying milestones directly with your Board Exams goal.'
                                ]);
                              } else if (tab === 'weekly') {
                                setCustomRecommendations([
                                  'Maintain your 14-day streak masterclass; Saturdays show slight productivity slumps.',
                                  'Set exactly 3 milestone blocks for Study Neurology to lock down pass board exams goal.',
                                  'Audit your break frequencies on Tuesday - we noted high restless cognitive patterns.'
                                ]);
                              } else {
                                setCustomRecommendations([
                                  'Your average completion score has climbed by 12% following morning blocks.',
                                  'Sera recommends scheduling complex coding task sprints strictly in 9:00 - 11:30 slots.',
                                  'Draft a long-term outline for PASS BOARD EXAMS by linking remaining tasks.'
                                ]);
                              }
                            }}
                            className={`py-1 px-2 rounded-md text-[9px] font-bold uppercase tracking-wider transition-all ${
                              insightsTab === tab 
                                ? 'bg-white text-gray-900 shadow-3xs border border-gray-100' 
                                : 'text-gray-400 hover:text-gray-600'
                            }`}
                          >
                            {tab}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-3">
                      {customRecommendations.map((rec, i) => (
                        <div key={i} className="flex gap-3 bg-gray-50/50 p-3 rounded-xl border border-gray-100 hover:bg-gray-50 transition-colors">
                          <div className="w-5 h-5 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-700 shrink-0 text-[10px] font-bold">
                            {i + 1}
                          </div>
                          <p className="text-[11px] text-gray-700 leading-relaxed font-medium">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

              {/* TAB 3: LONG-TERM GOALS */}
              {activeProfileTab === 'goals' && (
                <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                      <CalendarCheck className="w-4 h-4 text-orange-500" />
                      Long-Term Goal Progress Tracks
                    </h3>
                    <p className="text-gray-500 text-[10px] mt-0.5">Calculated in real-time by measuring associated task completion rates</p>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    {goals.map((goal) => {
                      const goalTasks = tasks.filter(t => t.goalId === goal.id);
                      const totalGoalTasks = goalTasks.length;
                      const completedGoalTasks = goalTasks.filter(t => t.completed).length;
                      const progressPct = totalGoalTasks > 0 ? Math.round((completedGoalTasks / totalGoalTasks) * 100) : 0;

                      return (
                        <div key={goal.id} className="bg-gray-50/50 rounded-xl p-4 border border-gray-100 flex flex-col justify-between hover:bg-gray-50 transition-colors">
                          <div className="flex justify-between items-start gap-2">
                            <div>
                              <span className="font-display font-bold text-sm text-gray-800 block">{goal.name}</span>
                              <span className="text-[10px] text-gray-500 block mt-0.5">
                                {completedGoalTasks} of {totalGoalTasks} tasks finished • Deadline: {goal.deadline}
                              </span>
                            </div>
                            <span className="bg-orange-50 text-orange-700 border border-orange-100 text-[9px] font-bold uppercase px-2 py-0.5 rounded-full">
                              Active Track
                            </span>
                          </div>

                          <div className="mt-5 space-y-1.5">
                            <div className="flex justify-between items-center text-[10px] font-bold">
                              <span className="text-indigo-600">{progressPct}% Complete</span>
                              <span className="text-gray-400">Task Ratio</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${activeTheme.primaryBg} transition-all duration-500`}
                                style={{ width: `${progressPct}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}

                    {goals.length === 0 && (
                      <div className="text-center py-8 text-gray-400 border border-dashed border-gray-200 rounded-xl font-medium">
                        No goals have been linked in your task workspace yet.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: VOICE & SYNC PREFERENCES */}
              {activeProfileTab === 'preferences' && (
                <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                      <Settings className="w-4 h-4 text-gray-500" />
                      Sera Voice & Synchronization Settings
                    </h3>
                    <p className="text-gray-500 text-[10px] mt-0.5">Tune proactive reminders and sync standalone schedules</p>
                  </div>

                  <div className="space-y-4 pt-1">
                    {/* Calendar Sync */}
                    <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex justify-between items-center">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold text-gray-800 flex items-center gap-1.5">
                          <Calendar className="w-4 h-4 text-indigo-600" />
                          Calendar Synchronizer
                        </span>
                        <span className="text-[10px] text-gray-500 block">
                          Status: {isCalendarSynced ? `Synced (at ${syncTime})` : 'Offline / Standalone mode'}
                        </span>
                      </div>

                      <button
                        onClick={handleCalendarSync}
                        disabled={isSyncing}
                        className="px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 shadow-3xs flex items-center gap-1 disabled:opacity-50"
                      >
                        {isSyncing ? (
                          <>
                            <Loader2 className="w-3 h-3 animate-spin text-indigo-600" /> Syncing...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-3 h-3 text-indigo-600" /> Sync Calendar
                          </>
                        )}
                      </button>
                    </div>

                    {/* Speech aloud toggle */}
                    <div className="flex justify-between items-center py-2 border-b border-gray-50">
                      <div className="space-y-0.5">
                        <span className="text-xs font-semibold text-gray-800 block">Proactive Voice Narration</span>
                        <span className="text-[10px] text-gray-400 block">Read critical reminders aloud with vocal audio</span>
                      </div>
                      <button
                        onClick={toggleVoiceAloud}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          voiceSpokenAloud 
                            ? 'bg-amber-100 border-amber-200 text-amber-800' 
                            : 'bg-gray-50 border-gray-200 text-gray-400'
                        }`}
                      >
                        {voiceSpokenAloud ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                      </button>
                    </div>

                    {/* Speech speeds */}
                    <div className="flex justify-between items-center py-2 border-b border-gray-50">
                      <div className="space-y-0.5">
                        <span className="text-xs font-semibold text-gray-800 block">Sera Speech Playback Rate</span>
                        <span className="text-[10px] text-gray-400 block">Adjust speed of TTS speech blocks</span>
                      </div>
                      <select
                        value={voiceSpeed}
                        onChange={(e) => {
                          setVoiceSpeed(e.target.value);
                          localStorage.setItem('winwise_voice_speed', e.target.value);
                        }}
                        className="bg-gray-50 border border-gray-200 p-1.5 rounded-lg text-xs font-bold"
                      >
                        <option value="Slow">Slow (0.85x)</option>
                        <option value="Normal">Normal (1.05x)</option>
                        <option value="Fast">Fast (1.25x)</option>
                      </select>
                    </div>

                    {/* Notification Intensity */}
                    <div className="flex justify-between items-center py-2">
                      <div className="space-y-0.5">
                        <span className="text-xs font-semibold text-gray-800 block">Reminder Nudge Frequency</span>
                        <span className="text-[10px] text-gray-400 block">Tune intensity of proactive coach checking notifications</span>
                      </div>
                      <select
                        value={notificationIntensity}
                        onChange={(e) => {
                          setNotificationIntensity(e.target.value);
                          localStorage.setItem('winwise_notification_intensity', e.target.value);
                        }}
                        className="bg-gray-50 border border-gray-200 p-1.5 rounded-lg text-xs font-bold"
                      >
                        <option value="Low">Low (Chill Mode)</option>
                        <option value="Medium">Medium (Balanced)</option>
                        <option value="Intense">Intense (Strict Mode)</option>
                      </select>
                    </div>

                  </div>
                </div>
              )}

              {/* TAB 5: AI MEMORY & PRIVACY */}
              {activeProfileTab === 'privacy' && (
                <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                        <ShieldAlert className="w-4 h-4 text-red-500" />
                        AI Memory & Privacy Audit
                      </h3>
                      <p className="text-gray-500 text-[10px] mt-0.5">Inspect and refine facts stored in Sera's memory index</p>
                    </div>
                    <span className="bg-red-50 border border-red-100 text-red-700 px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider">
                      GDPR Compliance
                    </span>
                  </div>

                  {/* Facts list */}
                  <div className="space-y-2 max-h-48 overflow-y-auto border border-gray-100 rounded-xl p-3 bg-gray-50/50">
                    {memoryFacts.map((fact, index) => (
                      <div key={index} className="flex justify-between items-center gap-2 bg-white border border-gray-100 p-2.5 rounded-lg hover:shadow-2xs transition-all">
                        <span className="text-[10px] font-medium text-gray-700">{fact}</span>
                        <button
                          onClick={() => handleDeleteMemory(index)}
                          className="text-gray-300 hover:text-red-500 p-1 transition-colors shrink-0"
                          title="Forget this fact"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}

                    {memoryFacts.length === 0 && (
                      <div className="text-center py-6 text-gray-400 font-semibold">
                        No stored memories active. Complete some focus blocks to feed the analyzer!
                      </div>
                    )}
                  </div>

                  {/* Add memory custom fact */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Add custom habit behavior note..."
                      value={newMemoryInput}
                      onChange={(e) => setNewMemoryInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleAddMemory();
                      }}
                      className="flex-1 bg-white border border-gray-200 rounded-xl p-2.5 text-xs focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                    />
                    <button
                      onClick={handleAddMemory}
                      className="px-3.5 rounded-xl bg-gray-900 text-white hover:bg-gray-850 transition-colors flex items-center justify-center shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={handleExportMemories}
                      className="flex-1 py-2 rounded-xl bg-gray-50 hover:bg-gray-100 border border-gray-150 text-gray-700 font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
                    >
                      <FileJson className="w-3.5 h-3.5" /> Export Data JSON
                    </button>
                    <button
                      onClick={handleClearMemory}
                      className="flex-1 py-2 rounded-xl bg-red-50 hover:bg-red-100 border border-red-100 text-red-700 font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Wipe Memory Indexes
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 6: WORKSPACE THEME & ACCESSIBILITY */}
              {activeProfileTab === 'theme' && (
                <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs space-y-4">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                      <Palette className="w-4 h-4 text-emerald-500" />
                      Workspace Customization & Accents
                    </h3>
                    <p className="text-gray-500 text-[10px] mt-0.5">Tweak visual densities, color themes, and font accessibility</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-1">
                    
                    {/* Theme selector */}
                    <div className="space-y-2">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wide block">Accent Theme Selector</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {Object.values(THEMES).map((th) => (
                          <button
                            key={th.id}
                            onClick={() => onChangeTheme(th.id)}
                            className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                              themeKey === th.id 
                                ? 'bg-gray-900 text-white border-transparent shadow-xs' 
                                : 'bg-gray-50 hover:bg-gray-100 border-gray-200 text-gray-700'
                            }`}
                          >
                            <div className={`w-3 h-3 rounded-full ${th.primaryBg}`} />
                            <span className="text-xs font-semibold">{th.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Accessibility switches */}
                    <div className="space-y-3">
                      <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wide block">Accessibility Adaptations</span>
                      
                      <div className="space-y-3 bg-gray-50/50 p-4 rounded-xl border border-gray-100">
                        {/* Font toggle */}
                        <div className="flex justify-between items-center">
                          <div className="space-y-0.5">
                            <span className="text-xs font-semibold text-gray-800 block">High Readability (Mono)</span>
                            <span className="text-[10px] text-gray-400 block">Apply clean technical monospace text</span>
                          </div>
                          <button
                            onClick={changeAccessibilityFont}
                            className={`px-2.5 py-1.5 rounded-lg border text-[10px] font-bold uppercase transition-all ${
                              highReadabilityFont 
                                ? 'bg-emerald-100 border-emerald-200 text-emerald-800' 
                                : 'bg-white border-gray-200 text-gray-500'
                            }`}
                          >
                            {highReadabilityFont ? 'Enabled' : 'Disabled'}
                          </button>
                        </div>

                        {/* Reduce Motion */}
                        <div className="flex justify-between items-center">
                          <div className="space-y-0.5">
                            <span className="text-xs font-semibold text-gray-800 block">Reduce Motion</span>
                            <span className="text-[10px] text-gray-400 block">Minimize tab changes and list translations</span>
                          </div>
                          <button
                            onClick={changeAccessibilityMotion}
                            className={`px-2.5 py-1.5 rounded-lg border text-[10px] font-bold uppercase transition-all ${
                              reduceMotion 
                                ? 'bg-emerald-100 border-emerald-200 text-emerald-800' 
                                : 'bg-white border-gray-200 text-gray-500'
                            }`}
                          >
                            {reduceMotion ? 'Reduced' : 'Standard'}
                          </button>
                        </div>

                        {/* Theme mode */}
                        <div className="flex justify-between items-center">
                          <div className="space-y-0.5">
                            <span className="text-xs font-semibold text-gray-800 block">Light / Dark Appearance</span>
                            <span className="text-[10px] text-gray-400 block">Switch current applet appearance presets</span>
                          </div>
                          <select
                            value={themeMode}
                            onChange={(e) => {
                              setThemeMode(e.target.value);
                              localStorage.setItem('winwise_theme_mode', e.target.value);
                            }}
                            className="bg-white border border-gray-200 p-1.5 rounded-lg text-xs font-bold"
                          >
                            <option value="Light">System (Light)</option>
                            <option value="Dark">Cosmic Dark</option>
                          </select>
                        </div>

                      </div>
                    </div>

                  </div>
                </div>
              )}

            </motion.div>
          </AnimatePresence>
        </div>

      </div>

    </div>
  );
}
