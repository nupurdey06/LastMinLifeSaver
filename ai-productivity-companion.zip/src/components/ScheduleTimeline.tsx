import React, { useState } from 'react';
import { Task, DailySchedule, ScheduleBlock, StressAssessment } from '../types';
import { Theme, THEMES } from '../theme';
import { motion } from 'motion/react';
import { 
  CalendarRange, 
  Sparkles, 
  Clock, 
  Coffee, 
  BrainCircuit, 
  Bed, 
  Play, 
  Smile, 
  CheckCircle2, 
  HelpCircle,
  Dumbbell,
  Moon,
  Activity
} from 'lucide-react';

interface ScheduleTimelineProps {
  tasks: Task[];
  schedule: DailySchedule | null;
  onGenerateSchedule: (preferences: {
    sleepHours: { start: string; end: string };
    focusPreference: 'morning' | 'afternoon' | 'evening';
    workDurationHours: number;
  }) => Promise<void>;
  isGenerating: boolean;
  onSelectTaskForFocus: (taskId: string) => void;
  theme?: Theme;
  stressAssessment?: StressAssessment | null;
  onGenerateStressSchedule?: (preferences: {
    sleepHours: { start: string; end: string };
    focusPreference: 'morning' | 'afternoon' | 'evening';
    workDurationHours: number;
    sleepPatterns: { hours: number; quality: string };
    calendarDensity: number;
  }) => Promise<void>;
  isGeneratingStress?: boolean;
}

export default function ScheduleTimeline({
  tasks,
  schedule,
  onGenerateSchedule,
  isGenerating,
  onSelectTaskForFocus,
  theme = THEMES.slate,
  stressAssessment,
  onGenerateStressSchedule,
  isGeneratingStress = false
}: ScheduleTimelineProps) {
  const [sleepStart, setSleepStart] = useState('23:00');
  const [sleepEnd, setSleepEnd] = useState('07:00');
  const [focusPreference, setFocusPreference] = useState<'morning' | 'afternoon' | 'evening'>('morning');
  const [workHours, setWorkHours] = useState(8);

  // Optional Cognitive stress modifiers
  const [sleepHoursLastNight, setSleepHoursLastNight] = useState(7.5);
  const [sleepQuality, setSleepQuality] = useState<'Restless' | 'Standard' | 'Restorative'>('Standard');
  const [calendarDensity, setCalendarDensity] = useState(2);

  const handleGenerate = () => {
    onGenerateSchedule({
      sleepHours: { start: sleepStart, end: sleepEnd },
      focusPreference,
      workDurationHours: workHours
    });
  };

  const handleGenerateStress = () => {
    if (onGenerateStressSchedule) {
      onGenerateStressSchedule({
        sleepHours: { start: sleepStart, end: sleepEnd },
        focusPreference,
        workDurationHours: workHours,
        sleepPatterns: { hours: sleepHoursLastNight, quality: sleepQuality },
        calendarDensity
      });
    }
  };

  return (
    <div id="schedule-timeline-container" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-gray-100 pb-5 mb-5">
        <h2 className="text-xl font-display font-semibold text-gray-900 flex items-center gap-2">
          <CalendarRange className={`w-5 h-5 ${theme.primaryText}`} />
          Personalized Routine Builder
        </h2>
        <p className="text-sm text-gray-500 mt-1">Generate a high-efficiency chronological day schedule</p>
      </div>

      {/* Preferences panel */}
      <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 mb-6 space-y-4">
        <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Timeline Controls</span>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Sleeping preferences */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-gray-500 uppercase flex items-center gap-1">
              <Bed className="w-3.5 h-3.5 text-gray-400" /> Sleeping Hours
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="23:00"
                value={sleepStart}
                onChange={(e) => setSleepStart(e.target.value)}
                className={`w-full bg-white border border-gray-200 text-xs rounded-lg p-2 text-center font-mono focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
              />
              <span className="text-gray-400 self-center text-xs">to</span>
              <input
                type="text"
                placeholder="07:00"
                value={sleepEnd}
                onChange={(e) => setSleepEnd(e.target.value)}
                className={`w-full bg-white border border-gray-200 text-xs rounded-lg p-2 text-center font-mono focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
              />
            </div>
          </div>

          {/* Peak Focus Preference */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-gray-500 uppercase flex items-center gap-1">
              <BrainCircuit className="w-3.5 h-3.5 text-gray-400" /> Peak Focus Time
            </label>
            <select
              value={focusPreference}
              onChange={(e) => setFocusPreference(e.target.value as any)}
              className={`bg-white border border-gray-200 text-xs rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
            >
              <option value="morning">Morning (08:00 - 12:00)</option>
              <option value="afternoon">Afternoon (13:00 - 17:00)</option>
              <option value="evening">Evening (18:00 - 22:00)</option>
            </select>
          </div>

          {/* Daily Work Target */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-semibold text-gray-500 uppercase flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-gray-400" /> Target Work Duration
            </label>
            <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg p-1">
              <input
                type="range"
                min="2"
                max="14"
                value={workHours}
                onChange={(e) => setWorkHours(Number(e.target.value))}
                className="flex-1 h-1.5 rounded-full cursor-pointer appearance-none bg-gray-100"
                style={{ accentColor: theme.primaryBg.includes('slate') ? '#475569' : theme.primaryBg.includes('rose') ? '#e11d48' : theme.primaryBg.includes('amber') ? '#d97706' : theme.primaryBg.includes('emerald') ? '#059669' : theme.primaryBg.includes('teal') ? '#0d9488' : theme.primaryBg.includes('violet') ? '#7c3aed' : '#4f46e5' }}
              />
              <span className="text-xs font-mono font-semibold text-gray-700 w-12 text-center bg-gray-50 py-1 rounded">
                {workHours} Hrs
              </span>
            </div>
          </div>
        </div>

        {/* Advanced Stress inputs */}
        <div className="border-t border-gray-200/65 pt-4 mt-2 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-gray-400" /> Cognitive Stress Modifiers
            </span>
            <span className="text-[9px] font-semibold text-gray-400 italic">Optional but highly recommended</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Sleep Hours last night */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-semibold text-gray-500 uppercase flex items-center gap-1">
                <Moon className="w-3.5 h-3.5 text-gray-400" /> Sleep Last Night
              </label>
              <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg p-1.5">
                <input
                  type="range"
                  min="4"
                  max="11"
                  step="0.5"
                  value={sleepHoursLastNight}
                  onChange={(e) => setSleepHoursLastNight(Number(e.target.value))}
                  className="flex-1 h-1 rounded-full cursor-pointer appearance-none bg-gray-100"
                  style={{ accentColor: theme.primaryBg.includes('slate') ? '#475569' : theme.primaryBg.includes('rose') ? '#e11d48' : theme.primaryBg.includes('amber') ? '#d97706' : theme.primaryBg.includes('emerald') ? '#059669' : theme.primaryBg.includes('teal') ? '#0d9488' : theme.primaryBg.includes('violet') ? '#7c3aed' : '#4f46e5' }}
                />
                <span className="text-[11px] font-mono font-bold text-gray-700 w-12 text-center bg-gray-50 py-1 rounded">
                  {sleepHoursLastNight} h
                </span>
              </div>
            </div>

            {/* Sleep Quality */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-semibold text-gray-500 uppercase flex items-center gap-1">
                <Smile className="w-3.5 h-3.5 text-gray-400" /> Sleep Quality
              </label>
              <select
                value={sleepQuality}
                onChange={(e) => setSleepQuality(e.target.value as any)}
                className={`bg-white border border-gray-200 text-xs rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
              >
                <option value="Restless">Restless (Interrupted)</option>
                <option value="Standard">Standard (Moderate)</option>
                <option value="Restorative">Restorative (Deep/Solid)</option>
              </select>
            </div>

            {/* Calendar Density */}
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-semibold text-gray-500 uppercase flex items-center gap-1">
                <CalendarRange className="w-3.5 h-3.5 text-gray-400" /> Calendar Density
              </label>
              <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg px-2 py-1">
                <input
                  type="number"
                  min="0"
                  max="12"
                  value={calendarDensity}
                  onChange={(e) => setCalendarDensity(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full text-xs font-mono font-semibold text-gray-700 focus:outline-none bg-transparent"
                />
                <span className="text-[10px] text-gray-400 shrink-0">events</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
          <button
            onClick={handleGenerateStress}
            disabled={isGenerating || isGeneratingStress || tasks.length === 0}
            className={`flex-1 ${theme.primaryBg} ${theme.primaryHover} disabled:bg-gray-300 disabled:cursor-not-allowed text-white text-xs font-semibold py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all shadow-xs hover:scale-[1.01]`}
          >
            <Sparkles className={`w-4 h-4 ${isGeneratingStress ? 'animate-spin' : ''}`} />
            {isGeneratingStress ? 'Optimizing Mind & Schedule...' : 'Optimize via Stress & Focus AI'}
          </button>

          <button
            onClick={handleGenerate}
            disabled={isGenerating || isGeneratingStress || tasks.length === 0}
            className="sm:w-1/3 bg-white hover:bg-gray-50 border border-gray-200 text-gray-600 text-xs font-semibold py-2.5 rounded-lg flex items-center justify-center gap-1.5 transition-all"
          >
            <Clock className="w-4 h-4 text-gray-400" />
            Standard Schedule
          </button>
        </div>

        {tasks.length === 0 && (
          <p className="text-[10px] text-red-500 text-center font-medium mt-1">Please add at least one task to build your schedule timeline.</p>
        )}
      </div>

      {/* Stress Assessment Dashboard */}
      {stressAssessment && (
        <motion.div 
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-50/70 border border-gray-150 rounded-xl p-5 mb-6 space-y-4 shadow-2xs"
        >
          <div className="flex items-center justify-between border-b border-gray-150 pb-3">
            <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
              <BrainCircuit className={`w-4 h-4 ${theme.primaryText}`} />
              WinWise Mind & Workload Status
            </h3>
            <span className="text-[10px] font-mono text-gray-400 bg-gray-100 px-2.5 py-0.5 rounded-full font-bold">
              Cognitive Guard Active
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Stress level gauge */}
            <div className="bg-white rounded-lg p-3.5 border border-gray-100 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Estimated Stress Level</span>
                <span className={`text-lg font-display font-bold block mt-1 ${
                  stressAssessment.stressScore >= 70 ? 'text-red-600' :
                  stressAssessment.stressScore >= 40 ? 'text-amber-600' : 'text-emerald-600'
                }`}>
                  {stressAssessment.stressScore}% • {stressAssessment.stressLabel}
                </span>
              </div>
              <div className="w-full bg-gray-100 h-2 rounded-full mt-2.5 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${
                    stressAssessment.stressScore >= 70 ? 'bg-red-500' :
                    stressAssessment.stressScore >= 40 ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${stressAssessment.stressScore}%` }}
                />
              </div>
            </div>

            {/* Cognitive load gauge */}
            <div className="bg-white rounded-lg p-3.5 border border-gray-100 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Cognitive Load Index</span>
                <span className={`text-lg font-display font-bold block mt-1 ${
                  stressAssessment.cognitiveLoadScore >= 70 ? 'text-red-600' :
                  stressAssessment.cognitiveLoadScore >= 40 ? 'text-amber-600' : 'text-emerald-600'
                }`}>
                  {stressAssessment.cognitiveLoadScore}% • {stressAssessment.cognitiveLoadLabel}
                </span>
              </div>
              <div className="w-full bg-gray-100 h-2 rounded-full mt-2.5 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${
                    stressAssessment.cognitiveLoadScore >= 70 ? 'bg-red-500' :
                    stressAssessment.cognitiveLoadScore >= 40 ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${stressAssessment.cognitiveLoadScore}%` }}
                />
              </div>
            </div>
          </div>

          {/* AI budget breakdown */}
          <div className={`rounded-lg p-3 text-xs border border-amber-100/40 bg-amber-50/20 text-gray-700 leading-relaxed italic`}>
            &quot;{stressAssessment.analysis}&quot;
          </div>

          {/* Predicted focus windows */}
          <div>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-2">Predicted Peak Focus Windows</span>
            <div className="flex flex-wrap gap-2">
              {stressAssessment.peakFocusPeriods.map((period, i) => (
                <div key={i} className={`flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-md border ${theme.primaryLightBorder} ${theme.primaryLightBg} ${theme.primaryLightText} font-medium`}>
                  <BrainCircuit className="w-3.5 h-3.5 shrink-0" />
                  <span>{period.label}: <strong className="font-mono">{period.start} - {period.end}</strong></span>
                </div>
              ))}
            </div>
          </div>

          {/* Postponed tasks */}
          {stressAssessment.postponedTasksCount > 0 && (
            <div className="bg-orange-50/60 border border-orange-100 rounded-lg p-3.5 space-y-2">
              <span className="text-[10px] font-bold text-orange-800 uppercase tracking-wider block">
                🛡️ AI Focus Protection: Postponed Low-Priority Work ({stressAssessment.postponedTasksCount})
              </span>
              <ul className="text-xs text-orange-900 space-y-1 list-disc list-inside">
                {stressAssessment.postponedTaskTitles.map((title, i) => (
                  <li key={i} className="font-medium">{title}</li>
                ))}
              </ul>
              <p className="text-[10px] text-orange-700">
                These tasks have been deferred to tomorrow to prevent burnout and ensure you can maintain peak cognitive concentration.
              </p>
            </div>
          )}
        </motion.div>
      )}

      {/* Generated Timeline Content */}
      <div className="flex-1 overflow-y-auto max-h-[420px] pr-1">
        {!schedule ? (
          <div className="flex flex-col items-center justify-center py-14 text-center border border-dashed border-gray-150 rounded-2xl">
            <CalendarRange className="w-8 h-8 text-gray-300 stroke-1 animate-pulse" />
            <p className="text-sm text-gray-500 font-medium mt-3">No schedule generated yet</p>
            <p className="text-xs text-gray-400 mt-1">Configure your sleeping/peak hours and click generate.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {schedule.generationAdvice && (
              <div className={`${theme.primaryLightBg} border ${theme.primaryLightBorder}/60 rounded-xl p-3 text-xs flex gap-2`}>
                <Sparkles className={`w-4 h-4 ${theme.primaryText} shrink-0 mt-0.5`} />
                <p className="text-gray-700 leading-relaxed font-medium italic">
                  &quot;{schedule.generationAdvice}&quot;
                </p>
              </div>
            )}

            {/* Timelines Cards */}
            <div className="relative border-l-2 border-gray-100 ml-4 pl-6 space-y-5">
              {schedule.blocks.map((block, index) => {
                const isBreak = block.type === 'break';
                const isFocus = block.type === 'focus';
                const isAdmin = block.type === 'admin';
                const isLeisure = block.type === 'leisure';

                // Find associated task title if applicable
                const matchedTask = block.associatedTaskId ? tasks.find(t => t.id === block.associatedTaskId) : null;

                return (
                  <motion.div
                    key={block.id || index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="relative group"
                  >
                    {/* Time Dot Indicator */}
                    <span className={`absolute -left-[31px] top-1.5 w-4 h-4 rounded-full border-2 bg-white flex items-center justify-center transition-all ${
                      isBreak 
                        ? 'border-green-500 text-green-500' 
                        : isFocus 
                        ? 'border-blue-600 text-blue-600' 
                        : isAdmin 
                        ? 'border-amber-500 text-amber-500'
                        : 'border-purple-500 text-purple-500'
                    }`}>
                      {isBreak && <Coffee className="w-2 h-2" />}
                      {isFocus && <BrainCircuit className="w-2 h-2" />}
                    </span>

                    {/* Block card */}
                    <div className={`p-4 rounded-xl border transition-all ${
                      isBreak
                        ? 'bg-green-50/50 border-green-100 hover:border-green-200'
                        : isFocus
                        ? 'bg-blue-50/30 border-blue-100 hover:border-blue-200'
                        : isAdmin
                        ? 'bg-amber-50/40 border-amber-100 hover:border-amber-200'
                        : 'bg-purple-50/40 border-purple-100 hover:border-purple-200'
                    }`}>
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-bold text-gray-500">
                              {block.timeStart} - {block.timeEnd}
                            </span>
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                              isBreak 
                                ? 'bg-green-100 text-green-800' 
                                : isFocus 
                                ? 'bg-blue-100 text-blue-800' 
                                : isAdmin 
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-purple-100 text-purple-800'
                            }`}>
                              {block.type}
                            </span>
                          </div>

                          <h4 className="text-sm font-semibold text-gray-900 mt-1.5">
                            {block.title}
                          </h4>

                          {matchedTask && (
                            <div className="mt-1 flex items-center gap-1.5">
                              <span className="text-[10px] font-bold text-gray-400 uppercase">Focusing on:</span>
                              <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100/30">
                                {matchedTask.title}
                              </span>
                            </div>
                          )}

                          {block.aiAdvice && (
                            <p className="text-xs text-gray-600 mt-2 italic flex items-center gap-1.5">
                              {isBreak ? (
                                <Smile className="w-3.5 h-3.5 text-green-600 shrink-0" />
                              ) : (
                                <HelpCircle className={`w-3.5 h-3.5 ${theme.primaryText} shrink-0`} />
                              )}
                              {block.aiAdvice}
                            </p>
                          )}
                        </div>

                        {/* Fast active action trigger for Focus session */}
                        {isFocus && matchedTask && !matchedTask.completed && (
                          <button
                            onClick={() => onSelectTaskForFocus(matchedTask.id)}
                            className="bg-white hover:bg-blue-600 text-blue-600 hover:text-white border border-blue-100 hover:border-blue-600 rounded-lg p-2 transition-all shadow-xs shrink-0 self-center group-hover:scale-105"
                            title="Start Guided Sprint"
                          >
                            <Play className="w-4 h-4 fill-current" />
                          </button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
