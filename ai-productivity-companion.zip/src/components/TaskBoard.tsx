import React, { useState } from 'react';
import { Task, UserRole, SubTask, Goal, UserProfile } from '../types';
import { Theme, THEMES } from '../theme';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  CheckSquare, 
  Square, 
  Sparkles, 
  Calendar, 
  Clock, 
  User, 
  CheckCircle, 
  AlertTriangle, 
  ChevronDown, 
  ChevronUp,
  BrainCircuit,
  Activity,
  Target,
  Flame,
  Award,
  ChevronRight,
  Info
} from 'lucide-react';

interface TaskBoardProps {
  tasks: Task[];
  onAddTask: (task: Omit<Task, 'id' | 'createdAt' | 'subTasks' | 'completed'>) => void;
  onToggleTask: (taskId: string) => void;
  onToggleSubTask: (taskId: string, subTaskId: string) => void;
  onDeleteTask: (taskId: string) => void;
  onPrioritize: (energyLevel: 'High' | 'Medium' | 'Low') => Promise<void>;
  isPrioritizing: boolean;
  userRole: UserRole;
  onChangeUserRole: (role: UserRole) => void;
  goals: Goal[];
  onAddGoal: (name: string, deadline: string) => void;
  onDeleteGoal: (id: string) => void;
  userProfile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
  onCompleteTaskWithReflection: (taskId: string, actualTime: number, completionStatus: 'early' | 'on-time' | 'late') => void;
  theme?: Theme;
}

export default function TaskBoard({
  tasks,
  onAddTask,
  onToggleTask,
  onToggleSubTask,
  onDeleteTask,
  onPrioritize,
  isPrioritizing,
  userRole,
  onChangeUserRole,
  goals,
  onAddGoal,
  onDeleteGoal,
  userProfile,
  onUpdateProfile,
  onCompleteTaskWithReflection,
  theme = THEMES.slate
}: TaskBoardProps) {
  // Add Task Form States
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<UserRole>('General');
  const [deadline, setDeadline] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [duration, setDuration] = useState(30);
  const [priority, setPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
  const [selectedGoalId, setSelectedGoalId] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  
  // App settings & goals UI toggle
  const [showProfileManager, setShowProfileManager] = useState(false);
  const [newGoalName, setNewGoalName] = useState('');
  const [newGoalDeadline, setNewGoalDeadline] = useState(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });

  // Profile Editor States
  const [editName, setEditName] = useState(userProfile.name);
  const [editRole, setEditRole] = useState(userProfile.customRole);
  const [editStreak, setEditStreak] = useState(userProfile.streakDays);

  // Reflection/Spark Celebration Overlay States
  const [reflectingTask, setReflectingTask] = useState<Task | null>(null);
  const [actualTime, setActualTime] = useState(30);
  const [completionStatus, setCompletionStatus] = useState<'early' | 'on-time' | 'late'>('on-time');
  const [isSparkLoading, setIsSparkLoading] = useState(false);
  const [sparkCelebrationText, setSparkCelebrationText] = useState<string | null>(null);
  const [sparkError, setSparkError] = useState<string | null>(null);

  const [expandedTasks, setExpandedTasks] = useState<Record<string, boolean>>({});
  const [energyLevel, setEnergyLevel] = useState<'High' | 'Medium' | 'Low'>('Medium');

  const playCelebrationChord = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const frequencies = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
      frequencies.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.06, ctx.currentTime + 0.05 + idx * 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.8 + idx * 0.1);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 1.2);
      });
    } catch (e) {
      console.warn("Celebration audio skipped", e);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onAddTask({
      title,
      description,
      category,
      deadline,
      estimatedDuration: Number(duration),
      priority,
      goalId: selectedGoalId || undefined
    });
    setTitle('');
    setDescription('');
    setDuration(30);
    setSelectedGoalId('');
    setShowAddForm(false);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: editName,
      customRole: editRole,
      streakDays: Number(editStreak)
    });
    setShowProfileManager(false);
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalName.trim()) return;
    onAddGoal(newGoalName, newGoalDeadline);
    setNewGoalName('');
  };

  const handleOpenReflection = (task: Task) => {
    setReflectingTask(task);
    setActualTime(task.estimatedDuration);
    setCompletionStatus('on-time');
    setSparkCelebrationText(null);
    setSparkError(null);
  };

  const handleTriggerSparkCelebration = async () => {
    if (!reflectingTask) return;
    setIsSparkLoading(true);
    setSparkError(null);

    // Calculate time of day based on current hour
    const hour = new Date().getHours();
    let timeOfDay = 'work hours';
    if (hour >= 5 && hour < 9) timeOfDay = 'early morning';
    else if (hour >= 9 && hour < 18) timeOfDay = 'work hours';
    else if (hour >= 18 && hour < 22) timeOfDay = 'evening';
    else timeOfDay = 'late night';

    // Find active goal detail
    let goalPayload = null;
    if (reflectingTask.goalId) {
      const activeGoal = goals.find(g => g.id === reflectingTask.goalId);
      if (activeGoal) {
        const goalTasks = tasks.filter(t => t.goalId === activeGoal.id);
        const completedCount = goalTasks.filter(t => t.completed).length + 1; // plus this one
        goalPayload = {
          name: activeGoal.name,
          completedTasks: completedCount,
          totalTasks: Math.max(goalTasks.length, activeGoal.totalTasksCount, 1),
          deadline: activeGoal.deadline,
          timeOfDay
        };
      }
    }

    if (!goalPayload) {
      // Fallback
      const todayTasks = tasks;
      const completedToday = todayTasks.filter(t => t.completed).length + 1;
      goalPayload = {
        name: "Daily Workload",
        completedTasks: completedToday,
        totalTasks: Math.max(todayTasks.length, 1),
        deadline: "Tonight",
        timeOfDay
      };
    }

    try {
      const res = await fetch('/api/spark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user: {
            name: userProfile.name,
            role: userProfile.customRole,
            streak: userProfile.streakDays
          },
          task: {
            title: reflectingTask.title,
            description: reflectingTask.description || "",
            category: reflectingTask.category,
            completionStatus: completionStatus,
            actualTime: actualTime,
            estimatedTime: reflectingTask.estimatedDuration
          },
          goal: goalPayload
        })
      });

      if (!res.ok) {
        throw new Error("Spark model request interrupted.");
      }

      const data = await res.json();
      if (data && data.celebration) {
        setSparkCelebrationText(data.celebration);
        playCelebrationChord();
      } else {
        throw new Error("No celebration returned");
      }
    } catch (err: any) {
      console.error(err);
      setSparkError("Could not retrieve custom Sera cheer. But your effort is fully recorded! Keep pushing!");
      playCelebrationChord();
    } finally {
      setIsSparkLoading(false);
    }
  };

  const handleFinishReflection = () => {
    if (reflectingTask) {
      onCompleteTaskWithReflection(reflectingTask.id, actualTime, completionStatus);
      setReflectingTask(null);
    }
  };

  const toggleExpand = (taskId: string) => {
    setExpandedTasks(prev => ({ ...prev, [taskId]: !prev[taskId] }));
  };

  // Sort tasks: pending first, then by AI Score (descending), then standard priority, then completed last
  const sortedTasks = [...tasks].sort((a, b) => {
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    const scoreA = a.aiScore || 0;
    const scoreB = b.aiScore || 0;
    if (scoreA !== scoreB) {
      return scoreB - scoreA;
    }
    const priorityWeight = { High: 3, Medium: 2, Low: 1 };
    return priorityWeight[b.priority] - priorityWeight[a.priority];
  });

  return (
    <div id="task-board-container" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col h-full relative">
      
      {/* Header with Role & Spark profile toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-5 mb-5">
        <div>
          <h2 className="text-xl font-display font-semibold text-gray-900 flex items-center gap-2">
            <CheckSquare className={`w-5 h-5 ${theme.primaryText}`} />
            Task Workspace
          </h2>
          <p className="text-xs text-gray-500 mt-1">
            Organized under your active goals
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowProfileManager(!showProfileManager)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border flex items-center gap-1.5 transition-all ${
              showProfileManager 
                ? `${theme.primaryLightBg} ${theme.primaryLightText} ${theme.primaryLightBorder}` 
                : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Sera Companion Settings
          </button>
        </div>
      </div>

      {/* Spark Profile & Goals Manager Panel */}
      <AnimatePresence>
        {showProfileManager && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden bg-gray-50 border border-gray-150 rounded-xl p-4 mb-5 space-y-4 text-xs"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Profile Config */}
              <form onSubmit={handleSaveProfile} className="space-y-3 bg-white p-3.5 rounded-lg border border-gray-100">
                <h3 className="font-bold text-gray-800 flex items-center gap-1.5 text-xs">
                  <Award className={`w-4 h-4 ${theme.primaryText}`} />
                  User Profile Context
                </h3>
                <p className="text-[10px] text-gray-500 leading-tight">These parameters feed directly into Sera's dynamic encouragement engine.</p>
                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Your Name</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className={`w-full bg-gray-50 border border-gray-200 rounded p-1.5 mt-1 focus:outline-none focus:ring-1 ${theme.primaryFocus} font-semibold text-gray-800`}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase">Specific Role / Goal Bio</label>
                    <input
                      type="text"
                      value={editRole}
                      onChange={(e) => setEditRole(e.target.value)}
                      placeholder="e.g. medical student, startup founder"
                      className={`w-full bg-gray-50 border border-gray-200 rounded p-1.5 mt-1 focus:outline-none focus:ring-1 ${theme.primaryFocus} font-semibold text-gray-800`}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-gray-400 uppercase flex items-center gap-1">
                      <Flame className="w-3 h-3 text-amber-500" /> Current Streak (Days)
                    </label>
                    <input
                      type="number"
                      value={editStreak}
                      onChange={(e) => setEditStreak(Number(e.target.value))}
                      className={`w-full bg-gray-50 border border-gray-200 rounded p-1.5 mt-1 focus:outline-none focus:ring-1 ${theme.primaryFocus} font-semibold text-gray-800`}
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className={`w-full ${theme.primaryBg} ${theme.primaryHover} text-white font-bold py-1.5 rounded transition-colors text-[10px]`}
                >
                  Save Context Values
                </button>
              </form>

              {/* Goals Config */}
              <div className="space-y-3 bg-white p-3.5 rounded-lg border border-gray-100 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-gray-800 flex items-center gap-1.5 text-xs">
                    <Target className="w-4 h-4 text-emerald-600" />
                    Bigger Goals Alignment
                  </h3>
                  <p className="text-[10px] text-gray-500 leading-tight mb-2">Define primary milestone containers to trace task completed distance.</p>

                  <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1 mb-2">
                    {goals.length === 0 ? (
                      <p className="text-gray-400 italic text-[10px]">No macro goals active yet.</p>
                    ) : (
                      goals.map(g => {
                        const goalTasks = tasks.filter(t => t.goalId === g.id);
                        const completedCount = goalTasks.filter(t => t.completed).length;
                        return (
                          <div key={g.id} className="flex items-center justify-between bg-gray-50 border border-gray-150 rounded p-1.5 text-[11px]">
                            <div className="truncate pr-2">
                              <span className="font-semibold text-gray-800 block truncate">{g.name}</span>
                              <span className="text-[9px] text-gray-400 block mt-0.5">Deadline: {g.deadline} | Progress: {completedCount}/{Math.max(goalTasks.length, 1)} tasks</span>
                            </div>
                            <button
                              onClick={() => onDeleteGoal(g.id)}
                              className="text-gray-300 hover:text-red-500 p-1"
                              title="Delete Goal"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                <form onSubmit={handleCreateGoal} className="border-t border-gray-100 pt-2 flex flex-col gap-1.5">
                  <input
                    type="text"
                    placeholder="New Goal Title (e.g. Board Exams)"
                    value={newGoalName}
                    onChange={(e) => setNewGoalName(e.target.value)}
                    className={`bg-gray-50 border border-gray-200 rounded p-1 focus:outline-none focus:ring-1 ${theme.primaryFocus} text-[10px]`}
                  />
                  <div className="flex gap-2">
                    <input
                      type="date"
                      value={newGoalDeadline}
                      onChange={(e) => setNewGoalDeadline(e.target.value)}
                      className={`bg-gray-50 border border-gray-200 rounded p-1 focus:outline-none focus:ring-1 ${theme.primaryFocus} text-[10px] flex-1`}
                    />
                    <button
                      type="submit"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1 rounded transition-colors text-[10px]"
                    >
                      Add
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* AI Prioritizer Action Bar */}
      <div className={`bg-gradient-to-r ${theme.gradientFromTo} border ${theme.primaryBorder} rounded-xl p-4 mb-5 flex flex-col md:flex-row items-center justify-between gap-4`}>
        <div className="flex items-center gap-3">
          <div className={`${theme.primaryBg} p-2.5 rounded-lg text-white transition-all duration-300`}>
            <BrainCircuit className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 text-sm flex items-center gap-1.5">
              Smart Prioritizer
            </h3>
            <p className="text-xs text-gray-600 mt-0.5">Analyzes deadlines, complexity, and sets tactical steps.</p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          {/* Energy selector */}
          <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-lg p-1 text-xs">
            <span className="text-[10px] text-gray-400 px-1 font-semibold uppercase">Energy:</span>
            {(['Low', 'Medium', 'High'] as const).map((energy) => (
              <button
                key={energy}
                onClick={() => setEnergyLevel(energy)}
                className={`px-2.5 py-1 rounded-md font-medium transition-all duration-300 ${
                  energyLevel === energy
                    ? `${theme.primaryBg} text-white`
                    : 'text-gray-500 hover:bg-gray-100'
                }`}
              >
                {energy}
              </button>
            ))}
          </div>

          <button
            onClick={() => onPrioritize(energyLevel)}
            disabled={isPrioritizing || tasks.length === 0}
            className={`flex-1 md:flex-none flex items-center justify-center gap-2 ${theme.primaryBg} ${theme.primaryHover} disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-medium text-xs px-4 py-2.5 rounded-lg shadow-xs transition-all duration-300`}
          >
            <Sparkles className={`w-4 h-4 ${isPrioritizing ? 'animate-spin' : ''}`} />
            {isPrioritizing ? 'Analyzing...' : 'Prioritize Tasks'}
          </button>
        </div>
      </div>

      {/* Add Task Toggle & Form */}
      <div className="mb-4">
        {!showAddForm ? (
          <button
            onClick={() => setShowAddForm(true)}
            className={`w-full flex items-center justify-center gap-2 border border-dashed border-gray-200 hover:border-gray-400 hover:${theme.primaryLightBg}/30 text-gray-600 hover:${theme.primaryText} font-medium py-3 rounded-xl text-sm transition-all duration-300`}
          >
            <Plus className="w-4 h-4" />
            Add New Commitment
          </button>
        ) : (
          <motion.form 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            onSubmit={handleSubmit} 
            className="bg-gray-50 rounded-xl p-4 border border-gray-100 flex flex-col gap-3"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Task Title</label>
                <input
                  type="text"
                  placeholder="e.g. Build API endpoints"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className={`bg-white border border-gray-200 text-sm rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
                  required
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as UserRole)}
                  className={`bg-white border border-gray-200 text-sm rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
                >
                  <option value="Student">Student</option>
                  <option value="Professional">Professional</option>
                  <option value="Entrepreneur">Entrepreneur</option>
                  <option value="General">General</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Description</label>
              <textarea
                placeholder="Details or resources..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className={`bg-white border border-gray-200 text-sm rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus} h-16 resize-none`}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Deadline</label>
                <input
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className={`bg-white border border-gray-200 text-sm rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Est. Duration (Mins)</label>
                <input
                  type="number"
                  min="5"
                  max="480"
                  value={duration}
                  onChange={(e) => setDuration(Number(e.target.value))}
                  className={`bg-white border border-gray-200 text-sm rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Priority</label>
                <div className="flex items-center gap-1 bg-white border border-gray-200 rounded-lg p-1">
                  {(['Low', 'Medium', 'High'] as const).map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPriority(p)}
                      className={`flex-1 py-1 rounded text-xs font-medium transition-all ${
                        priority === p
                          ? p === 'High'
                            ? 'bg-red-500 text-white'
                            : p === 'Medium'
                            ? 'bg-amber-500 text-white'
                            : 'bg-emerald-500 text-white'
                          : 'text-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Bigger Goal Alignment */}
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Bigger Goal Alignment</label>
              <select
                value={selectedGoalId}
                onChange={(e) => setSelectedGoalId(e.target.value)}
                className={`bg-white border border-gray-200 text-sm rounded-lg p-2 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
              >
                <option value="">-- No Specific Macro Goal --</option>
                {goals.map(g => (
                  <option key={g.id} value={g.id}>{g.name}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 mt-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 border border-gray-200 text-gray-500 hover:bg-gray-100 rounded-lg text-xs font-semibold transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                className={`px-4 py-2 ${theme.primaryBg} ${theme.primaryHover} text-white rounded-lg text-xs font-semibold transition-all shadow-xs`}
              >
                Create Task
              </button>
            </div>
          </motion.form>
        )}
      </div>

      {/* Tasks List */}
      <div className="flex-1 overflow-y-auto pr-1 max-h-[850px] lg:max-h-none">
        {sortedTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center border border-dashed border-gray-100 rounded-2xl">
            <Activity className="w-8 h-8 text-gray-300 stroke-1 animate-pulse" />
            <p className="text-sm text-gray-500 font-medium mt-3">Your workspace is empty.</p>
            <p className="text-xs text-gray-400 mt-1">Add tasks above to begin organizing.</p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            <AnimatePresence initial={false}>
              {sortedTasks.map((task) => {
                const isExpanded = !!expandedTasks[task.id];
                const completedSubtasks = task.subTasks.filter(s => s.completed).length;
                const totalSubtasks = task.subTasks.length;
                const percentComplete = totalSubtasks > 0 ? Math.round((completedSubtasks / totalSubtasks) * 100) : 0;
                const linkedGoal = goals.find(g => g.id === task.goalId);

                return (
                  <motion.div
                    key={task.id}
                    layoutId={`task-card-${task.id}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className={`border rounded-xl transition-all duration-200 ${
                      task.completed 
                        ? 'bg-gray-50/60 border-gray-100 opacity-75' 
                        : 'bg-white border-gray-150 hover:border-gray-350 hover:shadow-2xs'
                    }`}
                  >
                    {/* Top Core Block */}
                    <div className="p-4 flex items-start gap-3">
                      {/* Completion check */}
                      <button
                        onClick={() => {
                          if (task.completed) {
                            onToggleTask(task.id);
                          } else {
                            handleOpenReflection(task);
                          }
                        }}
                        className={`mt-0.5 text-gray-400 hover:${theme.primaryText} transition-colors`}
                      >
                        {task.completed ? (
                          <CheckCircle className="w-5 h-5 text-emerald-500 fill-emerald-50" />
                        ) : (
                          <div className={`w-5 h-5 rounded-md border-2 border-gray-300 hover:border-gray-400 transition-colors`} />
                        )}
                      </button>

                      {/* Info block */}
                      <div className="flex-1 min-w-0" onClick={() => toggleExpand(task.id)}>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            task.category === 'Student' 
                              ? 'bg-purple-50 text-purple-600 border border-purple-100'
                              : task.category === 'Professional'
                              ? 'bg-blue-50 text-blue-600 border border-blue-100'
                              : task.category === 'Entrepreneur'
                              ? 'bg-amber-50 text-amber-600 border border-amber-100'
                              : 'bg-gray-100 text-gray-600'
                          }`}>
                            {task.category}
                          </span>

                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            task.priority === 'High'
                              ? 'bg-red-50 text-red-600 border border-red-100'
                              : task.priority === 'Medium'
                              ? 'bg-amber-50 text-amber-600 border border-amber-100'
                              : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                          }`}>
                            {task.priority}
                          </span>

                          {task.postponed && (
                            <span className="bg-orange-50 text-orange-700 border border-orange-200 text-[10px] px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                              <Clock className="w-3 h-3 text-orange-500" />
                              Postponed by WinWise
                            </span>
                          )}

                          {task.aiScore !== undefined && (
                            <div className={`flex items-center gap-1 ${theme.primaryLightBg} border ${theme.primaryLightBorder} ${theme.primaryLightText} text-[10px] px-2 py-0.5 rounded-full font-bold`}>
                              <Sparkles className="w-3 h-3" />
                              Priority Score: {task.aiScore}
                            </div>
                          )}

                          {linkedGoal && (
                            <div className="flex items-center gap-1 bg-teal-50 border border-teal-100 text-teal-700 text-[10px] px-2 py-0.5 rounded-full font-bold">
                              <Target className="w-3 h-3 text-teal-600" />
                              {linkedGoal.name}
                            </div>
                          )}
                        </div>

                        <h4 className={`text-sm font-semibold mt-1.5 transition-all truncate ${
                          task.completed ? 'line-through text-gray-400' : 'text-gray-900'
                        }`}>
                          {task.title}
                        </h4>

                        {task.description && (
                          <p className="text-xs text-gray-500 mt-1 line-clamp-1">{task.description}</p>
                        )}

                        <div className="flex items-center gap-3 mt-2.5 text-[11px] text-gray-400 font-medium">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            {task.deadline}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" />
                            {task.estimatedDuration} mins
                          </span>
                          {totalSubtasks > 0 && (
                            <span className="flex items-center gap-1 font-mono bg-gray-50 border border-gray-100 px-1.5 py-0.5 rounded">
                              {completedSubtasks}/{totalSubtasks} subtasks ({percentComplete}%)
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Expand / Actions */}
                      <div className="flex flex-col items-end gap-1.5 self-stretch justify-between">
                        <button
                          onClick={() => onDeleteTask(task.id)}
                          className="text-gray-300 hover:text-red-500 p-1 rounded-md hover:bg-gray-50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => toggleExpand(task.id)}
                          className="text-gray-400 hover:text-gray-700 p-1"
                        >
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Expandable Justification and Subtask Breakdown */}
                    {isExpanded && (
                      <div className="border-t border-gray-100 bg-gray-50/50 p-4 rounded-b-xl space-y-3.5 text-xs">
                        {/* AI Postponed banner */}
                        {task.postponed && task.postponedReason && (
                          <div className="bg-orange-50/80 border border-orange-100 rounded-lg p-2.5 flex gap-2">
                            <Clock className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold text-orange-800 block text-[10px] uppercase tracking-wide">Postponed by WinWise AI</span>
                              <p className="text-gray-700 mt-0.5 italic">{task.postponedReason}</p>
                            </div>
                          </div>
                        )}

                        {/* AI Justification info box */}
                        {task.aiJustification && (
                          <div className={`${theme.primaryLightBg}/60 border ${theme.primaryLightBorder}/50 rounded-lg p-2.5 flex gap-2`}>
                            <BrainCircuit className={`w-4 h-4 ${theme.primaryText} shrink-0 mt-0.5`} />
                            <div>
                              <span className={`font-bold ${theme.primaryLightText} block text-[10px] uppercase tracking-wide`}>Recommendation Context</span>
                              <p className="text-gray-700 mt-0.5 italic">{task.aiJustification}</p>
                            </div>
                          </div>
                        )}

                        {/* Spark Reflection Log if completed */}
                        {task.completed && task.completionStatus && (
                          <div className="bg-emerald-50/60 border border-emerald-100 rounded-lg p-2.5 flex gap-2">
                            <Award className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold text-emerald-800 block text-[10px] uppercase tracking-wide">Sera Metric Logged</span>
                              <p className="text-gray-700 mt-0.5">
                                Finished <span className="font-bold">{task.completionStatus}</span> in <span className="font-bold">{task.actualTime || task.estimatedDuration} minutes</span> (Target: {task.estimatedDuration}m).
                              </p>
                            </div>
                          </div>
                        )}

                        {/* Subtasks Block */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-bold text-gray-500 uppercase tracking-wider text-[10px]">Action Breakdown</span>
                            {totalSubtasks > 0 && (
                              <div className="w-24 bg-gray-200 h-1.5 rounded-full overflow-hidden">
                                <div className="bg-emerald-500 h-full transition-all duration-300" style={{ width: `${percentComplete}%` }} />
                              </div>
                            )}
                          </div>

                          {task.subTasks.length === 0 ? (
                            <p className="text-gray-400 italic text-[11px] pl-1">No subtasks generated yet. Click &quot;Prioritize Tasks&quot; to generate steps.</p>
                          ) : (
                            <div className="space-y-1.5">
                              {task.subTasks.map((sub) => (
                                <button
                                  key={sub.id}
                                  onClick={() => onToggleSubTask(task.id, sub.id)}
                                  className="w-full flex items-center gap-2 py-1 px-1.5 rounded-md hover:bg-white border border-transparent hover:border-gray-100 transition-all text-left"
                                >
                                  {sub.completed ? (
                                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                                  ) : (
                                    <div className="w-3.5 h-3.5 rounded border border-gray-300 hover:border-gray-400 shrink-0" />
                                  )}
                                  <span className={`text-xs ${sub.completed ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                                    {sub.text}
                                  </span>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Complete Task & Reflect with Spark Modal (Overlay) */}
      <AnimatePresence>
        {reflectingTask && (
          <div className="fixed inset-0 bg-gray-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-[9999]">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-xl border border-gray-150 max-w-lg w-full overflow-hidden"
            >
              {/* Header */}
              <div className={`bg-gradient-to-r ${theme.gradientFromTo} text-white p-5`}>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-300 animate-spin" style={{ animationDuration: '4s' }} />
                  <span className="text-[10px] font-bold tracking-widest uppercase opacity-90">Micro-Win Reflection Portal</span>
                </div>
                <h3 className="text-md font-bold mt-1.5 leading-tight">{reflectingTask.title}</h3>
                {reflectingTask.description && (
                  <p className="text-xs opacity-80 mt-1 line-clamp-1 italic">{reflectingTask.description}</p>
                )}
              </div>

              {/* Body */}
              <div className="p-6 space-y-5">
                {!sparkCelebrationText ? (
                  <>
                    <p className="text-xs text-gray-600 leading-normal">
                      Excellent work! Before Sera celebrates your win, take a brief moment to log your reflection metrics.
                    </p>

                    {/* Actual Time Spent */}
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-500 uppercase flex items-center justify-between">
                        <span>Actual Time Spent</span>
                        <span className={`font-mono text-xs ${theme.primaryText}`}>{actualTime} mins</span>
                      </label>
                      <input
                        type="range"
                        min="5"
                        max="240"
                        step="5"
                        value={actualTime}
                        onChange={(e) => setActualTime(Number(e.target.value))}
                        className="w-full h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer"
                        style={{ accentColor: theme.primaryBg.includes('slate') ? '#475569' : theme.primaryBg.includes('rose') ? '#e11d48' : theme.primaryBg.includes('amber') ? '#d97706' : theme.primaryBg.includes('emerald') ? '#059669' : theme.primaryBg.includes('teal') ? '#0d9488' : theme.primaryBg.includes('violet') ? '#7c3aed' : '#4f46e5' }}
                      />
                      <div className="flex justify-between text-[10px] text-gray-400 font-medium">
                        <span>Est: {reflectingTask.estimatedDuration}m</span>
                        <span>4 hours max</span>
                      </div>
                    </div>

                    {/* Completion Status */}
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-500 uppercase block">When was this completed?</label>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'early', label: 'Finished Early', desc: 'Maximized efficiency' },
                          { id: 'on-time', label: 'On Time', desc: 'Reliable follow-through' },
                          { id: 'late', label: 'Finished Late', desc: 'Fought through delays' }
                        ].map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => setCompletionStatus(item.id as any)}
                            className={`p-2.5 rounded-xl border text-left transition-all ${
                              completionStatus === item.id
                                ? `${theme.primaryLightBg} ${theme.primaryLightBorder} ${theme.primaryLightText} shadow-2xs`
                                : 'bg-white border-gray-200 text-gray-700 hover:border-gray-300'
                            }`}
                          >
                            <span className="text-xs font-bold block">{item.label}</span>
                            <span className="text-[9px] text-gray-400 mt-0.5 block leading-tight">{item.desc}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Submit Button */}
                    <button
                      onClick={handleTriggerSparkCelebration}
                      disabled={isSparkLoading}
                      className={`w-full ${theme.primaryBg} ${theme.primaryHover} disabled:opacity-50 text-white py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all`}
                    >
                      {isSparkLoading ? (
                        <>
                          <Sparkles className="w-4 h-4 animate-spin" />
                          Consulting Coach...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          Ignite Celebration Cheer
                        </>
                      )}
                    </button>
                  </>
                ) : (
                  /* Spark Celebration Display */
                  <div className="space-y-4 py-2">
                    <div className={`${theme.primaryLightBg} border ${theme.primaryLightBorder} rounded-2xl p-5 text-center relative overflow-hidden`}>
                      <div className="absolute top-0 right-0 p-3">
                        <Sparkles className={`w-8 h-8 ${theme.primaryText} opacity-30 animate-pulse`} />
                      </div>
                      <span className={`text-[10px] font-bold ${theme.primaryText} uppercase tracking-widest block mb-1`}>Sera Says:</span>
                      
                      <p className={`text-sm font-display font-medium ${theme.primaryLightText} leading-relaxed italic pr-2`}>
                        &quot;{sparkCelebrationText}&quot;
                      </p>
                    </div>

                    <div className="bg-gray-50 border border-gray-150 rounded-xl p-3 flex items-start gap-2.5 text-[11px] text-gray-500">
                      <Info className={`w-4 h-4 ${theme.primaryText} shrink-0 mt-0.5`} />
                      <p>
                        This personalized cheer was computed dynamically based on your <span className="font-semibold text-gray-700">{userProfile.customRole}</span> focus, your <span className="font-semibold text-gray-700">{userProfile.streakDays}-day streak</span>, and your <span className="font-semibold text-gray-700">{completionStatus}</span> completed timeline!
                      </p>
                    </div>

                    <button
                      onClick={handleFinishReflection}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Keep the Momentum Going!
                    </button>
                  </div>
                )}

                {sparkError && (
                  <div className="bg-red-50 border border-red-100 rounded-xl p-3 text-center text-xs text-red-700 font-medium">
                    {sparkError}
                    <button
                      onClick={handleFinishReflection}
                      className={`block mx-auto mt-2 ${theme.primaryText} hover:underline font-bold text-[11px]`}
                    >
                      Complete Task Anyway
                    </button>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="bg-gray-50 border-t border-gray-100 px-6 py-3 flex justify-end">
                <button
                  type="button"
                  onClick={() => setReflectingTask(null)}
                  className="text-xs text-gray-400 hover:text-gray-600 font-semibold"
                >
                  Cancel & Go Back
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
