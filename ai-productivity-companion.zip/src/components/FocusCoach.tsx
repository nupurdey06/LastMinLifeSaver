import React, { useState, useEffect, useRef } from 'react';
import { Task, CoachingResponse } from '../types';
import { Theme, THEMES } from '../theme';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  BrainCircuit, 
  Sparkles, 
  Lightbulb, 
  Compass, 
  CheckCircle, 
  Flame, 
  CheckCircle2, 
  AlertCircle,
  Volume2,
  VolumeX
} from 'lucide-react';

interface FocusCoachProps {
  tasks: Task[];
  onCompleteTask: (taskId: string) => void;
  theme?: Theme;
}

export default function FocusCoach({ tasks, onCompleteTask, theme = THEMES.slate }: FocusCoachProps) {
  const [selectedTaskId, setSelectedTaskId] = useState<string>('');
  const [mentalState, setMentalState] = useState<'starting' | 'procrastinating' | 'confused' | 'tired'>('procrastinating');
  const [customBarrier, setCustomBarrier] = useState('');
  const [coaching, setCoaching] = useState<CoachingResponse | null>(null);
  const [isLoadingCoach, setIsLoadingCoach] = useState(false);

  // Timer states
  const [timeLeft, setTimeLeft] = useState(15 * 60); // in seconds
  const [timerActive, setTimerActive] = useState(false);
  const [initialDuration, setInitialDuration] = useState(15 * 60);
  const [isMuted, setIsMuted] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const activeTask = tasks.find(t => t.id === selectedTaskId);
  const pendingTasks = tasks.filter(t => !t.completed);

  // Set default selected task if empty
  useEffect(() => {
    if (!selectedTaskId && pendingTasks.length > 0) {
      setSelectedTaskId(pendingTasks[0].id);
    }
  }, [pendingTasks, selectedTaskId]);

  // Handle timer ticks
  useEffect(() => {
    if (timerActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && timerActive) {
      setTimerActive(false);
      triggerAlarmSound();
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerActive, timeLeft]);

  // Audio Synthesizer (Safe standard AudioContext)
  const playSynthesizedTone = (frequency: number, durationMs: number, type: OscillatorType = 'sine') => {
    if (isMuted) return;
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);

      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + durationMs / 1000);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + durationMs / 1000);
    } catch (e) {
      console.warn("Synthesizer failed to generate sound, continuing silently", e);
    }
  };

  const triggerAlarmSound = () => {
    // Elegant dual chime alarm
    playSynthesizedTone(523.25, 200, 'sine'); // C5
    setTimeout(() => {
      playSynthesizedTone(659.25, 300, 'sine'); // E5
    }, 150);
  };

  const playClickFeedback = () => {
    playSynthesizedTone(880, 50, 'sine'); // Short high click
  };

  const handleFetchCoaching = async () => {
    if (!activeTask) return;
    setIsLoadingCoach(true);
    playClickFeedback();
    try {
      const response = await fetch('/api/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: activeTask,
          state: mentalState,
          userMessage: customBarrier
        })
      });
      if (!response.ok) throw new Error("Coaching call failed");
      const data: CoachingResponse = await response.json();
      setCoaching(data);

      // Align timer with coach recommendation
      const recommendedSec = data.timerMinutes * 60;
      setTimeLeft(recommendedSec);
      setInitialDuration(recommendedSec);
      setTimerActive(false);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoadingCoach(false);
    }
  };

  const toggleTimer = () => {
    playClickFeedback();
    setTimerActive(!timerActive);
  };

  const resetTimer = () => {
    playClickFeedback();
    setTimerActive(false);
    setTimeLeft(initialDuration);
  };

  const handleSprintComplete = () => {
    playSynthesizedTone(523.25, 500, 'sine');
    if (activeTask) {
      onCompleteTask(activeTask.id);
      setCoaching(null);
    }
  };

  // Compute timing labels
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progressPercent = ((initialDuration - timeLeft) / initialDuration) * 100;

  return (
    <div id="focus-coach-container" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col h-full">
      {/* Header */}
      <div className="flex justify-between items-center border-b border-gray-100 pb-5 mb-5">
        <div>
          <h2 className="text-xl font-display font-semibold text-gray-900 flex items-center gap-2">
            <Compass className={`w-5 h-5 ${theme.primaryText} animate-spin`} style={{ animationDuration: '6s' }} />
            Anti-Procrastination Space
          </h2>
          <p className="text-sm text-gray-500 mt-1">Dissolve mental barriers with micro-step coaching</p>
        </div>
        <button
          onClick={() => setIsMuted(!isMuted)}
          className="text-gray-400 hover:text-gray-600 p-2 rounded-lg bg-gray-50 border border-gray-100 transition-colors"
          title={isMuted ? 'Unmute Sound Synthesis' : 'Mute Sound'}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
      </div>

      {pendingTasks.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center py-12">
          <Flame className="w-10 h-10 text-amber-500 stroke-1" />
          <h4 className="font-semibold text-gray-900 mt-4 text-sm">Perfect Focus Streak!</h4>
          <p className="text-xs text-gray-500 mt-2">All tasks are currently completed. Add tasks to start coaching sprint.</p>
        </div>
      ) : (
        <div className="flex-1 flex flex-col gap-5">
          {/* Active Task Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Select focus commitment</label>
            <select
              value={selectedTaskId}
              onChange={(e) => {
                setSelectedTaskId(e.target.value);
                setCoaching(null);
              }}
              className={`w-full bg-white border border-gray-200 text-sm rounded-xl p-2.5 font-medium text-gray-800 focus:outline-none focus:ring-1 ${theme.primaryFocus}`}
            >
              {pendingTasks.map(t => (
                <option key={t.id} value={t.id}>{t.title} ({t.priority} Priority)</option>
              ))}
            </select>
          </div>

          {/* Core coaching setup form (when no active coaching block) */}
          {!coaching && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              {/* Mental Barrier States */}
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wide block">How do you feel about this task?</span>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'procrastinating', label: 'Procrastinating', detail: 'Avoiding starting' },
                    { id: 'starting', label: 'Stuck/Overwhelmed', detail: 'Too big to handle' },
                    { id: 'confused', label: 'Confused', detail: 'Don\'t know first step' },
                    { id: 'tired', label: 'Fatigued/Tired', detail: 'Energy is spent' }
                  ].map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setMentalState(s.id as any)}
                      className={`p-3 text-left border rounded-xl transition-all ${
                        mentalState === s.id
                          ? `${theme.primaryLightBg} ${theme.primaryLightBorder} ${theme.primaryLightText} shadow-xs`
                          : 'bg-white border-gray-155 hover:border-gray-300'
                      }`}
                    >
                      <span className="text-xs font-bold block">{s.label}</span>
                      <span className="text-[10px] text-gray-500 mt-0.5 block">{s.detail}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom feedback input */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">Tell the coach what&apos;s on your mind (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. I only have 10 minutes, or I feel distracted..."
                  value={customBarrier}
                  onChange={(e) => setCustomBarrier(e.target.value)}
                  className={`w-full bg-white border border-gray-200 text-xs rounded-xl p-3 focus:outline-none focus:ring-1 ${theme.primaryFocus} placeholder-gray-400`}
                />
              </div>

              <button
                onClick={handleFetchCoaching}
                disabled={isLoadingCoach}
                className={`w-full ${theme.primaryBg} ${theme.primaryHover} disabled:opacity-50 text-white font-semibold text-xs py-3 rounded-xl flex items-center justify-center gap-2 transition-all shadow-xs`}
              >
                <BrainCircuit className="w-4 h-4" />
                {isLoadingCoach ? 'Busting Resistance...' : 'Request Strategic Micro-Step'}
              </button>
            </motion.div>
          )}

          {/* Active coaching & timer layout */}
          {coaching && (
            <AnimatePresence>
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex-1 flex flex-col gap-4"
              >
                {/* Micro Step Card */}
                <div className={`${theme.primaryLightBg}/70 border ${theme.primaryLightBorder} rounded-2xl p-4`}>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`${theme.primaryBg} text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1`}>
                      <Sparkles className="w-3 h-3 animate-spin" /> Coach Guidance
                    </span>
                    <button
                      onClick={() => {
                        setCoaching(null);
                        setTimerActive(false);
                      }}
                      className={`text-xs font-semibold ${theme.primaryLightText} hover:opacity-85`}
                    >
                      Change Mode
                    </button>
                  </div>

                  <p className="text-xs text-gray-800 leading-relaxed font-medium">
                    &quot;{coaching.message}&quot;
                  </p>

                  <div className={`mt-4 bg-white/80 rounded-xl p-3 border ${theme.primaryLightBorder} flex items-start gap-2`}>
                    <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-gray-500 uppercase tracking-wide text-[9px] block">Your Ridiculous Micro-Step</span>
                      <p className={`text-xs font-semibold ${theme.primaryLightText} mt-1`}>
                        {coaching.microStep}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Timer block */}
                <div className="flex-1 flex flex-col justify-center items-center py-4 bg-gray-50/50 border border-gray-100 rounded-2xl relative overflow-hidden">
                  {/* Subtle progress ring bar bg */}
                  <div 
                    className={`absolute bottom-0 left-0 h-1 ${theme.primaryBg} transition-all duration-1000`}
                    style={{ width: `${progressPercent}%` }}
                  />

                  <div className={`text-4xl font-mono font-bold ${theme.primaryLightText} tracking-wider`}>
                    {formatTime(timeLeft)}
                  </div>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Sprint Timer</span>

                  {/* Actions */}
                  <div className="flex gap-2.5 mt-4">
                    <button
                      onClick={toggleTimer}
                      className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs ${
                        timerActive 
                          ? 'bg-amber-500 hover:bg-amber-600 text-white' 
                          : `${theme.primaryBg} ${theme.primaryHover} text-white`
                      }`}
                    >
                      {timerActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      {timerActive ? 'Pause Sprint' : 'Start Focus'}
                    </button>
                    <button
                      onClick={resetTimer}
                      className="p-2 border border-gray-200 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                      title="Reset Timer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Check In Panel */}
                <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 flex items-center justify-between gap-3 text-xs">
                  <div className="flex gap-2 items-center">
                    <AlertCircle className={`w-4 h-4 ${theme.primaryText} shrink-0`} />
                    <p className="text-gray-700 leading-tight">
                      <span className="font-bold block">Check-in:</span>
                      {coaching.checkInQuestion}
                    </p>
                  </div>
                  <button
                    onClick={handleSprintComplete}
                    className="bg-green-600 hover:bg-green-700 text-white font-semibold px-3 py-1.5 rounded-lg shrink-0 flex items-center gap-1 transition-all text-[11px]"
                  >
                    <CheckCircle className="w-3.5 h-3.5" /> Done!
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          )}
        </div>
      )}
    </div>
  );
}
