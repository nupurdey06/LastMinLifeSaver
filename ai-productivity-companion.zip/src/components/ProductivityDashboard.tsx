import React, { useState, useEffect } from 'react';
import { Task, ProductivityInsights } from '../types';
import { Theme, THEMES } from '../theme';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { 
  TrendingUp, 
  CheckCircle, 
  Hourglass, 
  BrainCircuit, 
  Sparkles, 
  Lightbulb, 
  ArrowUpRight, 
  BookOpen, 
  Zap,
  Activity
} from 'lucide-react';

interface ProductivityDashboardProps {
  tasks: Task[];
  insights: ProductivityInsights | null;
  onRefreshInsights: () => Promise<void>;
  isRefreshing: boolean;
  theme?: Theme;
}

export default function ProductivityDashboard({
  tasks,
  insights,
  onRefreshInsights,
  isRefreshing,
  theme = THEMES.slate
}: ProductivityDashboardProps) {

  // Auto-fetch insights once tasks are loaded/changed
  useEffect(() => {
    if (tasks.length > 0 && !insights) {
      onRefreshInsights();
    }
  }, [tasks, insights, onRefreshInsights]);

  // Compute local fallbacks if insights api isn't fetched yet
  const completedCount = tasks.filter(t => t.completed).length;
  const pendingCount = tasks.filter(t => !t.completed).length;
  const totalCount = tasks.length;
  const localCompletionRate = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Prepare chart data 1: Category Distribution
  const categoryCounts = tasks.reduce((acc, task) => {
    acc[task.category] = (acc[task.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const chartDataCategory = Object.keys(categoryCounts).map(cat => ({
    name: cat,
    value: categoryCounts[cat]
  }));

  // Prepare chart data 2: Priority Completion ratios
  const priorityStatus = ['High', 'Medium', 'Low'].map(p => {
    const priorityTasks = tasks.filter(t => t.priority === p);
    const completed = priorityTasks.filter(t => t.completed).length;
    const total = priorityTasks.length;
    return {
      priority: p,
      total,
      completed,
      pending: total - completed
    };
  });

  // Color mappings
  const COLORS = {
    Student: '#a855f7', // purple
    Professional: '#3b82f6', // blue
    Entrepreneur: '#f59e0b', // amber
    General: '#6b7280' // gray
  };

  return (
    <div id="productivity-dashboard" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col h-full space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-5">
        <div>
          <h2 className="text-xl font-display font-semibold text-gray-900 flex items-center gap-2">
            <TrendingUp className={`w-5 h-5 ${theme.primaryText}`} />
            Workspace Efficiency & Analytics
          </h2>
          <p className="text-sm text-gray-500 mt-1">Deep analysis of workload, completion velocity, and recommendations</p>
        </div>

        <button
          onClick={onRefreshInsights}
          disabled={isRefreshing || tasks.length === 0}
          className={`flex items-center gap-2 ${theme.primaryLightBg} hover:${theme.primaryLightBg}/80 disabled:bg-gray-100 ${theme.primaryLightText} disabled:text-gray-400 font-semibold text-xs px-4 py-2.5 rounded-xl transition-all border ${theme.primaryLightBorder}/50 self-start`}
        >
          <Sparkles className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Analyzing Trends...' : 'Recalculate Insights'}
        </button>
      </div>

      {tasks.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-16 text-center border border-dashed border-gray-150 rounded-2xl">
          <Activity className="w-8 h-8 text-gray-300 stroke-1 animate-pulse" />
          <p className="text-sm text-gray-500 font-medium mt-3">Analyze Your Performance</p>
          <p className="text-xs text-gray-400 mt-1">Add and complete a few commitments to generate insights.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left: Performance stats and graphs */}
          <div className="space-y-6">
            {/* Numeric Indicators */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-blue-50/50 border border-blue-100 p-4 rounded-xl text-center">
                <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest block">Completed</span>
                <span className="text-2xl font-bold text-blue-950 font-mono mt-1 block">{completedCount}</span>
              </div>
              <div className="bg-amber-50/50 border border-amber-100 p-4 rounded-xl text-center">
                <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest block">Active</span>
                <span className="text-2xl font-bold text-amber-950 font-mono mt-1 block">{pendingCount}</span>
              </div>
              <div className="bg-purple-50/50 border border-purple-100 p-4 rounded-xl text-center">
                <span className="text-[10px] font-bold text-purple-500 uppercase tracking-widest block">Success Rate</span>
                <span className="text-2xl font-bold text-purple-950 font-mono mt-1 block">{localCompletionRate}%</span>
              </div>
            </div>

            {/* Recharts chart: Priorities load */}
            <div className="border border-gray-100 rounded-xl p-4 bg-gray-50/20">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 block">Task Density by Priority</span>
              <div className="h-44 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={priorityStatus}>
                    <XAxis dataKey="priority" stroke="#888888" fontSize={10} tickLine={false} />
                    <YAxis stroke="#888888" fontSize={10} tickLine={false} />
                    <Tooltip cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                    <Bar dataKey="completed" name="Completed" fill="#22c55e" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="pending" name="Pending" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Category distribution pills */}
            <div className="border border-gray-100 rounded-xl p-4 bg-gray-50/20 space-y-3">
              <span className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Category Allocation</span>
              <div className="grid grid-cols-2 gap-2">
                {chartDataCategory.map(item => (
                  <div key={item.name} className="flex items-center justify-between p-2 rounded-lg bg-white border border-gray-100 text-xs">
                    <span className="flex items-center gap-1.5 font-medium text-gray-700">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: (COLORS as any)[item.name] }} />
                      {item.name}
                    </span>
                    <span className="font-mono font-bold text-gray-500">{item.value} tasks</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: AI smart insights */}
          <div className="space-y-4">
            {/* AI Efficiency Score Circle banner */}
            <div className={`${theme.primaryLightBg}/40 border ${theme.primaryLightBorder}/60 rounded-xl p-5 flex items-center justify-between gap-4`}>
              <div className="flex items-center gap-3">
                <div 
                  className="w-14 h-14 rounded-full text-white flex items-center justify-center font-bold text-xl shadow-xs shrink-0 font-mono transition-all duration-500"
                  style={{ background: theme.primaryBg.includes('slate') ? 'linear-gradient(135deg, #475569, #64748b)' : theme.primaryBg.includes('rose') ? 'linear-gradient(135deg, #e11d48, #fda4af)' : theme.primaryBg.includes('amber') ? 'linear-gradient(135deg, #d97706, #fcd34d)' : theme.primaryBg.includes('emerald') ? 'linear-gradient(135deg, #059669, #6ee7b7)' : theme.primaryBg.includes('teal') ? 'linear-gradient(135deg, #0d9488, #2dd4bf)' : theme.primaryBg.includes('violet') ? 'linear-gradient(135deg, #7c3aed, #c084fc)' : 'linear-gradient(135deg, #4f46e5, #a5b4fc)' }}
                >
                  {insights?.efficiencyScore ?? localCompletionRate}
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 text-sm flex items-center gap-1.5">
                    Workspace Health Score
                  </h4>
                  <p className="text-xs text-gray-500 mt-0.5">Calculated based on velocity, priority balance, and milestone completion.</p>
                </div>
              </div>
            </div>

            {/* Insights and Tips */}
            <div className="space-y-4">
              {/* Trends section */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Trend Insights</span>
                {insights?.insights ? (
                  <div className="space-y-2">
                    {insights.insights.map((insight, idx) => (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        key={idx}
                        className="p-3 bg-white border border-gray-150 rounded-xl flex items-start gap-2.5"
                      >
                        <Zap className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                        <span className="text-xs text-gray-700 leading-normal">{insight}</span>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 text-xs italic text-gray-500">
                    Press &quot;Recalculate Insights&quot; to fetch strategic work trends.
                  </div>
                )}
              </div>

              {/* Practical tips recommendations */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">Recommendations</span>
                {insights?.recommendations ? (
                  <div className="space-y-2">
                    {insights.recommendations.map((rec, idx) => (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 + 0.3 }}
                        key={idx}
                        className={`p-3 ${theme.primaryLightBg}/30 border ${theme.primaryLightBorder}/50 rounded-xl flex items-start gap-2.5`}
                      >
                        <Lightbulb className={`w-4 h-4 ${theme.primaryText} shrink-0 mt-0.5`} />
                        <span className={`text-xs ${theme.primaryLightText} font-medium leading-normal`}>{rec}</span>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 text-xs italic text-gray-500">
                    Personalized focus tactics will be formulated here.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
