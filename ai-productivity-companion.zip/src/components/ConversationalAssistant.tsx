import React, { useState, useEffect, useRef } from 'react';
import { Task, Goal, UserProfile, DailySchedule } from '../types';
import { Theme, THEMES } from '../theme';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  MicOff, 
  Send, 
  Sparkles, 
  Calendar, 
  Check, 
  CheckSquare, 
  Volume2, 
  VolumeX, 
  Clock, 
  Bell, 
  AlertCircle, 
  Trash2, 
  Bot, 
  User,
  Lightbulb,
  Zap,
  Smile,
  ChevronRight,
  ShieldAlert,
  Loader2
} from 'lucide-react';

interface ConversationalAssistantProps {
  tasks: Task[];
  goals: Goal[];
  userProfile: UserProfile;
  theme?: Theme;
  onAddTask: (task: Omit<Task, 'id' | 'createdAt' | 'subTasks' | 'completed'>) => void;
  onToggleTask: (taskId: string) => void;
  onGenerateSchedule: (preferences: {
    sleepHours: { start: string; end: string };
    focusPreference: 'morning' | 'afternoon' | 'evening';
    workDurationHours: number;
  }) => Promise<void>;
  onGenerateStressSchedule: (preferences: {
    sleepHours: { start: string; end: string };
    focusPreference: 'morning' | 'afternoon' | 'evening';
    workDurationHours: number;
    sleepPatterns: { hours: number; quality: string };
    calendarDensity: number;
  }) => Promise<void>;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedActions?: SuggestedAction[];
  isReminder?: boolean;
}

interface SuggestedAction {
  id: string;
  type: 'ADD_TASK' | 'GENERATE_SCHEDULE' | 'STRESS_SCHEDULE' | 'COMPLETE_TASK';
  label: string;
  payload: any;
  executed: boolean;
}

export default function ConversationalAssistant({
  tasks,
  goals,
  userProfile,
  theme = THEMES.slate,
  onAddTask,
  onToggleTask,
  onGenerateSchedule,
  onGenerateStressSchedule
}: ConversationalAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('winwise_assistant_chat');
    if (saved) return JSON.parse(saved);
    
    return [
      {
        id: 'welcome-1',
        sender: 'assistant',
        text: `Hello ${userProfile.name}! I am Sera, your voice-activated WinWise AI Guide. Describe a task you need to complete, ask me to schedule your day, or try clicking the microphone to talk to me. How can I help you win today?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
  });

  const [inputMessage, setInputMessage] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(false);
  const [activeReminders, setActiveReminders] = useState<boolean>(true);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [speechSupported, setSpeechSupported] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Parse speech support
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        setSpeechSupported(true);
        const rec = new SpeechRecognition();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = 'en-US';

        rec.onstart = () => {
          setIsListening(true);
          playBeep(440, 100); // Standard A4 tone
        };

        rec.onend = () => {
          setIsListening(false);
        };

        rec.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            setInputMessage(prev => {
              const base = prev.trim();
              return base ? `${base} ${transcript}` : transcript;
            });
          }
        };

        rec.onerror = (event: any) => {
          console.error("Speech recognition error:", event.error);
          setIsListening(false);
        };

        recognitionRef.current = rec;
      }
    }
  }, []);

  // Sync voice preference and list of voices
  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        const englishVoice = voices.find(v => v.lang.startsWith('en') && v.name.includes('Google')) ||
                             voices.find(v => v.lang.startsWith('en')) || 
                             voices[0];
        if (englishVoice) {
          setSelectedVoice(englishVoice);
        }
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  // Save chat messages
  useEffect(() => {
    localStorage.setItem('winwise_assistant_chat', JSON.stringify(messages));
    scrollToBottom();
  }, [messages]);

  // Proactive periodic notification simulator
  useEffect(() => {
    if (!activeReminders) return;

    const interval = setInterval(() => {
      // Choose a random helper reminder or task-related warning
      const pendingTasks = tasks.filter(t => !t.completed);
      if (pendingTasks.length === 0) return;

      const randomTask = pendingTasks[Math.floor(Math.random() * pendingTasks.length)];
      const triggerNotification = Math.random() > 0.4; // 60% chance to remind

      if (triggerNotification) {
        const hour = new Date().getHours();
        let reminderText = '';
        
        if (hour < 12) {
          reminderText = `Good morning, ${userProfile.name}! This is Sera. Let's make headway on "${randomTask.title}" during your morning peak focus zone. Would you like me to reserve focus blocks for this?`;
        } else if (hour < 17) {
          reminderText = `Hey ${userProfile.name}! Just a friendly check-in. "${randomTask.title}" has a pending deadline. A quick 15-minute start breaks procrastination instantly!`;
        } else {
          reminderText = `Wrapping up your day soon, ${userProfile.name}? Let's check off "${randomTask.title}" so you can sign off with complete peace of mind.`;
        }

        const newReminder: ChatMessage = {
          id: `reminder-${Date.now()}`,
          sender: 'assistant',
          text: reminderText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isReminder: true,
          suggestedActions: [
            {
              id: `action-rem-${Date.now()}-1`,
              type: 'COMPLETE_TASK',
              label: `Mark "${randomTask.title}" Complete`,
              payload: { taskId: randomTask.id },
              executed: false
            }
          ]
        };

        setMessages(prev => [...prev, newReminder]);
        speakText(reminderText);
        playBeep(587.33, 150); // D5 chime
      }
    }, 45000); // Trigger a gentle reminder check every 45 seconds to guarantee demonstration capability

    return () => clearInterval(interval);
  }, [activeReminders, tasks, userProfile]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const playBeep = (freq: number, duration: number) => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration / 1000);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration / 1000);
    } catch (e) {
      console.warn("Audio feedback synthesis unavailable", e);
    }
  };

  const speakText = (text: string) => {
    if (!isVoiceEnabled || typeof window === 'undefined' || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error("Speech synthesis failed", e);
    }
  };

  const toggleListening = () => {
    if (!speechSupported) {
      alert("Speech recognition is not supported in this browser. Please type your requests.");
      return;
    }
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      recognitionRef.current?.start();
    }
  };

  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed) return;

    // Add user message
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);
    playBeep(659.25, 80); // Clicks feedback

    try {
      const response = await fetch('/api/assistant/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          history: messages.slice(-10).map(m => ({
            role: m.sender === 'user' ? 'user' : 'model',
            text: m.text
          })),
          tasks: tasks,
          goals: goals,
          userProfile: userProfile
        })
      });

      if (!response.ok) throw new Error("Assistant response failed");
      const data = await response.json();

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: data.suggestedActions?.map((act: any, idx: number) => ({
          ...act,
          id: `act-${Date.now()}-${idx}`,
          executed: false
        }))
      };

      setMessages(prev => [...prev, assistantMsg]);
      speakText(data.spokenReply || data.reply);
      playBeep(523.25, 120); // Pleasant bell

    } catch (error) {
      console.error("Assistant chat error. Attempting safe fallback chat responder...", error);
      
      // Fallback AI rules
      const lower = trimmed.toLowerCase();
      let reply = `I'm here to support you, ${userProfile.name}! Let's make sure we conquer our daily plan.`;
      let spokenReply = reply;
      let actions: SuggestedAction[] = [];

      if (lower.includes('add') || lower.includes('create') || lower.includes('task') || lower.includes('todo')) {
        // Safe regex parser for tasks
        const words = trimmed.split(' ');
        let title = "Custom commit block";
        if (words.length > 2) {
          title = words.slice(2).join(' ').substring(0, 40);
        }
        reply = `I've prepared a new action task for you: "${title}". Shall I add this task to your plan with Medium priority?`;
        spokenReply = `I have prepared a new task: ${title}. Should I add it to your plan?`;
        actions = [
          {
            id: `act-fallback-${Date.now()}`,
            type: 'ADD_TASK',
            label: `Add Task: ${title}`,
            payload: {
              title: title,
              description: `Added via natural chat dialogue.`,
              priority: 'Medium',
              estimatedDuration: 45,
              deadline: new Date().toISOString().split('T')[0],
              category: 'General'
            },
            executed: false
          }
        ];
      } else if (lower.includes('schedule') || lower.includes('plan') || lower.includes('routine')) {
        reply = `I can instantly build an AI-optimized schedule aligned with your ${userProfile.customRole} priorities. Ready to sync?`;
        spokenReply = `I can optimize your daily routine. Click below to organize your timeline.`;
        actions = [
          {
            id: `act-fallback-${Date.now()}`,
            type: 'GENERATE_SCHEDULE',
            label: "Schedule with Focus Blocks",
            payload: {
              sleepHours: { start: '23:00', end: '07:00' },
              focusPreference: 'morning',
              workDurationHours: 8
            },
            executed: false
          }
        ];
      } else if (lower.includes('stress') || lower.includes('burnout') || lower.includes('tired') || lower.includes('heavy')) {
        reply = `Acknowledge the heavy stress load, ${userProfile.name}. I suggest executing a cognitive protection schedule to drop low priority work.`;
        spokenReply = `I've structured a stress protection schedule for you. Click the action button to apply it.`;
        actions = [
          {
            id: `act-fallback-${Date.now()}`,
            type: 'STRESS_SCHEDULE',
            label: "Activate Cognitive Protection Schedule",
            payload: {
              sleepHours: { start: '23:00', end: '07:00' },
              focusPreference: 'morning',
              workDurationHours: 8,
              sleepPatterns: { hours: 6.5, quality: 'Restless' },
              calendarDensity: 4
            },
            executed: false
          }
        ];
      } else {
        reply = `Got it, ${userProfile.name}. Understood! To keep your momentum strong, we can schedule our active focus sessions or add fresh subtasks. What would you like to build?`;
        spokenReply = `I'm ready. Let's schedule your tasks or map out your focus commitments.`;
      }

      const assistantFallbackMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedActions: actions
      };

      setMessages(prev => [...prev, assistantFallbackMsg]);
      speakText(spokenReply);
    } finally {
      setIsLoading(false);
    }
  };

  const handleExecuteAction = async (action: SuggestedAction, msgId: string) => {
    playBeep(880, 150); // Action accept chime
    
    try {
      if (action.type === 'ADD_TASK') {
        onAddTask(action.payload);
      } else if (action.type === 'GENERATE_SCHEDULE') {
        await onGenerateSchedule(action.payload);
      } else if (action.type === 'STRESS_SCHEDULE') {
        await onGenerateStressSchedule(action.payload);
      } else if (action.type === 'COMPLETE_TASK') {
        onToggleTask(action.payload.taskId);
      }

      // Mark as executed in state
      setMessages(prev => prev.map(m => {
        if (m.id === msgId && m.suggestedActions) {
          return {
            ...m,
            suggestedActions: m.suggestedActions.map(a => a.id === action.id ? { ...a, executed: true } : a)
          };
        }
        return m;
      }));
    } catch (e) {
      console.error(e);
    }
  };

  const clearChat = () => {
    playBeep(330, 200); // Wipe tone
    setMessages([
      {
        id: 'welcome-reset',
        sender: 'assistant',
        text: `Chat history cleared. I'm ready for fresh spoken instructions or scheduling commands, ${userProfile.name}!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  const triggerManualNotification = () => {
    // Force trigger a realistic high-value proactive reminder to prove capability
    playBeep(523.25, 200);
    const activeTasks = tasks.filter(t => !t.completed);
    let reminderText = `Hi ${userProfile.name}! Just checking in: your daily timeline needs a quick sync. Shall I arrange focus blocks to guarantee completion today?`;
    
    if (activeTasks.length > 0) {
      const topTask = activeTasks[0];
      reminderText = `Strategic Reminder: Your commitment to "${topTask.title}" requires full attention. Ready to start a 15-minute resistance buster sprint?`;
    }

    const manualReminder: ChatMessage = {
      id: `man-rem-${Date.now()}`,
      sender: 'assistant',
      text: reminderText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isReminder: true,
      suggestedActions: activeTasks.length > 0 ? [
        {
          id: `act-man-${Date.now()}`,
          type: 'COMPLETE_TASK',
          label: `Mark "${activeTasks[0].title}" Completed`,
          payload: { taskId: activeTasks[0].id },
          executed: false
        }
      ] : []
    };

    setMessages(prev => [...prev, manualReminder]);
    speakText(reminderText);
  };

  return (
    <div id="conversational-assistant-container" className="bg-white rounded-2xl border border-gray-100 shadow-xs p-6 flex flex-col h-[640px]">
      
      {/* Module Header */}
      <div className="flex justify-between items-center border-b border-gray-100 pb-4 mb-4">
        <div>
          <h2 className="text-xl font-display font-semibold text-gray-900 flex items-center gap-2">
            <Bot className={`w-5 h-5 ${theme.primaryText}`} />
            Sera Companion
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">Voice activated scheduler & conversational coach</p>
        </div>

        {/* Toolbar Controls */}
        <div className="flex items-center gap-2">
          {/* Proactive reminders toggle */}
          <button
            onClick={() => setActiveReminders(!activeReminders)}
            className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
              activeReminders 
                ? `${theme.accentBadge}` 
                : 'bg-gray-100 text-gray-400 hover:text-gray-600'
            }`}
            title="Proactive AI Reminders Toggle"
          >
            <Bell className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{activeReminders ? 'Reminders On' : 'Silent Mode'}</span>
          </button>

          {/* Test Reminder Trigger */}
          <button
            onClick={triggerManualNotification}
            className="p-2 rounded-xl text-xs font-semibold bg-gray-50 border border-gray-100 text-gray-600 hover:bg-gray-100 transition-colors"
            title="Force immediate AI reminder trigger"
          >
            <Zap className="w-3.5 h-3.5" />
          </button>

          {/* TTS Audio toggle */}
          <button
            onClick={() => setIsVoiceEnabled(!isVoiceEnabled)}
            className={`p-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors ${
              isVoiceEnabled 
                ? 'bg-amber-100 text-amber-800' 
                : 'bg-gray-100 text-gray-400 hover:text-gray-600'
            }`}
            title={isVoiceEnabled ? 'Voice Synthesis Active' : 'Voice Synthesis Muted'}
          >
            {isVoiceEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isVoiceEnabled ? 'Voice Aloud' : 'Mute Aloud'}</span>
          </button>

          {/* Clear history */}
          <button
            onClick={clearChat}
            className="text-gray-400 hover:text-gray-600 p-2 rounded-xl hover:bg-gray-50 transition-colors"
            title="Clear Chat History"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Feed Viewport */}
      <div className="flex-1 overflow-y-auto mb-4 space-y-4 pr-1 scrollbar-thin scrollbar-thumb-gray-200">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex gap-3 max-w-[85%] ${msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
            >
              {/* Avatar */}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 overflow-hidden ${
                msg.sender === 'user' 
                  ? userProfile.avatarUrl ? '' : `${theme.primaryBg} text-white` 
                  : msg.isReminder 
                    ? 'bg-amber-100 text-amber-700 border border-amber-200'
                    : 'bg-gray-100 text-gray-600 border border-gray-200'
              }`}>
                {msg.sender === 'user' ? (
                  userProfile.avatarUrl ? (
                    <img src={userProfile.avatarUrl} alt={userProfile.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <User className="w-4 h-4" />
                  )
                ) : (
                  <Bot className="w-4 h-4" />
                )}
              </div>

              {/* Message Block */}
              <div className="space-y-1.5">
                <div className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? `${theme.primaryBg} text-white rounded-tr-none font-medium`
                    : msg.isReminder
                      ? 'bg-amber-50/75 border border-amber-200/60 text-amber-950 rounded-tl-none font-medium'
                      : 'bg-gray-50/90 border border-gray-100 text-gray-800 rounded-tl-none'
                }`}>
                  {msg.isReminder && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-amber-800 uppercase tracking-wide mb-1.5">
                      <Bell className="w-3.5 h-3.5 animate-bounce" /> Proactive Guidance
                    </div>
                  )}
                  <p>{msg.text}</p>
                </div>

                {/* Proposed actions inside messages */}
                {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                  <div className="pl-1 space-y-2 mt-1">
                    {msg.suggestedActions.map((action) => (
                      <div 
                        key={action.id}
                        className="bg-white border border-gray-155 rounded-xl p-3 shadow-3xs flex flex-col gap-2 max-w-sm"
                      >
                        <div className="flex justify-between items-start gap-1">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1">
                            <Lightbulb className="w-3.5 h-3.5 text-amber-500" /> Proposed Action
                          </span>
                          {action.executed && (
                            <span className="text-[10px] font-bold text-green-600 flex items-center gap-0.5">
                              <Check className="w-3 h-3" /> Executed
                            </span>
                          )}
                        </div>
                        
                        <p className="text-[11px] font-bold text-gray-800">{action.label}</p>
                        
                        {action.type === 'ADD_TASK' && action.payload && (
                          <div className="text-[10px] text-gray-500 bg-gray-50 p-1.5 rounded-lg border border-gray-100 font-medium">
                            <span className="font-bold">Priority:</span> {action.payload.priority} | <span className="font-bold">Duration:</span> {action.payload.estimatedDuration}m
                          </div>
                        )}

                        <button
                          disabled={action.executed}
                          onClick={() => handleExecuteAction(action, msg.id)}
                          className={`w-full text-center font-bold text-[10px] py-1.5 px-3 rounded-lg transition-all ${
                            action.executed
                              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                              : `${theme.primaryBg} ${theme.primaryHover} text-white shadow-3xs`
                          }`}
                        >
                          {action.executed ? 'Action Applied' : 'Approve & Execute'}
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <span className="text-[10px] text-gray-400 px-1 block text-right font-medium">
                  {msg.timestamp}
                </span>
              </div>
            </motion.div>
          ))}

          {/* Typing/Thinking Loader */}
          {isLoading && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3"
            >
              <div className="w-8 h-8 rounded-full bg-gray-100 text-gray-600 border border-gray-200 flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-gray-50 border border-gray-100 p-3 rounded-2xl rounded-tl-none flex items-center gap-1.5 text-xs text-gray-400 font-medium">
                <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
                Sera is optimizing...
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Starters */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {[
          { label: "🎙️ Spoken task...", query: "I need to review user research notes for 30 minutes tomorrow." },
          { label: "📅 Schedule Day", query: "Can you schedule my afternoon starting at 1 PM?" },
          { label: "⚡ Stress Protection", query: "I'm feeling heavily stressed and tired. Optimize my cognitive load." }
        ].map((btn, idx) => (
          <button
            key={idx}
            onClick={() => {
              setInputMessage(btn.query);
              playBeep(440, 50);
            }}
            className="text-[10px] font-semibold text-gray-600 hover:text-gray-900 bg-gray-50 border border-gray-150 rounded-lg py-1 px-2.5 transition-all"
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Input Message Controls */}
      <div className="flex gap-2 items-center">
        {/* Real microphone speaking toggle */}
        <button
          onClick={toggleListening}
          className={`p-3 rounded-xl transition-all flex items-center justify-center shrink-0 shadow-xs border ${
            isListening 
              ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse border-red-600' 
              : 'bg-gray-50 hover:bg-gray-150 text-gray-600 border-gray-200'
          }`}
          title={isListening ? "Listening... click to stop" : "Speak your tasks naturally (Voice Recognition)"}
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Text Area */}
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleSendMessage(inputMessage);
            }
          }}
          placeholder={isListening ? "Listening to your voice..." : "Type or speak natural commitments..."}
          className={`flex-1 bg-white border border-gray-200 rounded-xl p-3 text-xs focus:outline-none focus:ring-1 ${theme.primaryFocus} placeholder-gray-400 font-medium`}
        />

        {/* Send button */}
        <button
          onClick={() => handleSendMessage(inputMessage)}
          disabled={!inputMessage.trim()}
          className={`p-3 rounded-xl text-white flex items-center justify-center transition-all shadow-xs ${
            inputMessage.trim() 
              ? `${theme.primaryBg} ${theme.primaryHover}` 
              : 'bg-gray-150 text-gray-400 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

      {/* Voice feedback banner when listening */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 bg-red-50 border border-red-200/50 p-2.5 rounded-xl flex items-center gap-2 text-xs text-red-800 font-semibold"
          >
            <span className="w-2 h-2 rounded-full bg-red-600 animate-ping shrink-0" />
            <span>Voice active: Speak your task, goal or routine command clearly...</span>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
